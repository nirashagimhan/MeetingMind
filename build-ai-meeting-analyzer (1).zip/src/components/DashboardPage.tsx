import React from 'react';
import { motion } from 'framer-motion';
import {
  BarChart3, Clock, Users, FileText, AlertCircle, CheckCircle,
  TrendingUp, Brain, Calendar, ArrowRight, Lightbulb, Flag,
  ChevronRight, Activity, Search, Filter, Plus
} from 'lucide-react';
import { Meeting } from '../types';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, AreaChart, Area } from 'recharts';

interface DashboardPageProps {
  meetings: Meeting[];
  setCurrentPage: (page: string) => void;
  setSelectedMeeting: (meeting: Meeting) => void;
}

const DashboardPage: React.FC<DashboardPageProps> = ({ meetings, setCurrentPage, setSelectedMeeting }) => {
  const completedMeetings = meetings.filter(m => m.status === 'completed');
  const totalProblems = completedMeetings.reduce((sum, m) => sum + (m.summary?.problems.length || 0), 0);
  const totalSolutions = completedMeetings.reduce((sum, m) => sum + (m.summary?.solutions.length || 0), 0);
  const totalActions = completedMeetings.reduce((sum, m) => sum + (m.summary?.actionItems.length || 0), 0);
  const pendingActions = completedMeetings.flatMap(m => m.summary?.actionItems || []).filter(a => a.status === 'pending').length;
  const avgScore = completedMeetings.length
    ? Math.round(completedMeetings.reduce((sum, m) => sum + (m.summary?.meetingScore || 0), 0) / completedMeetings.length)
    : 0;

  const trendData = [
    { week: 'W1', meetings: 2, actionItems: 8, problems: 3 },
    { week: 'W2', meetings: 4, actionItems: 15, problems: 6 },
    { week: 'W3', meetings: 3, actionItems: 12, problems: 4 },
    { week: 'W4', meetings: 5, actionItems: 20, problems: 8 },
    { week: 'W5', meetings: meetings.length, actionItems: totalActions, problems: totalProblems },
  ];

  const statusColors: Record<string, string> = {
    completed: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30',
    processing: 'text-amber-400 bg-amber-500/10 border-amber-500/30',
    error: 'text-red-400 bg-red-500/10 border-red-500/30',
  };

  const sentimentEmojis: Record<string, string> = {
    positive: '😊',
    negative: '😟',
    neutral: '😐',
    mixed: '🤔',
  };

  const handleMeetingClick = (meeting: Meeting) => {
    setSelectedMeeting(meeting);
    setCurrentPage('analysis');
  };

  return (
    <div className="min-h-screen bg-[#050510] pt-20 px-4 pb-12">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col md:flex-row md:items-center justify-between gap-4 py-8"
        >
          <div>
            <h1 className="text-3xl font-black text-white">Meeting Dashboard</h1>
            <p className="text-gray-400 mt-1">Your complete meeting intelligence overview</p>
          </div>
          <motion.button
            onClick={() => setCurrentPage('upload')}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-purple-600 text-white font-semibold text-sm shadow-lg shadow-purple-500/20"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Plus className="w-4 h-4" />
            New Analysis
          </motion.button>
        </motion.div>

        {/* Stats Row */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
          {[
            { label: 'Total Meetings', value: meetings.length, color: 'violet', icon: <FileText className="w-4 h-4" /> },
            { label: 'Avg Score', value: avgScore, suffix: '/100', color: 'blue', icon: <Brain className="w-4 h-4" /> },
            { label: 'Problems Found', value: totalProblems, color: 'rose', icon: <AlertCircle className="w-4 h-4" /> },
            { label: 'Solutions', value: totalSolutions, color: 'emerald', icon: <Lightbulb className="w-4 h-4" /> },
            { label: 'Action Items', value: totalActions, color: 'amber', icon: <CheckCircle className="w-4 h-4" /> },
            { label: 'Pending Tasks', value: pendingActions, color: 'orange', icon: <Activity className="w-4 h-4" /> },
          ].map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.08 }}
              className={`p-4 rounded-2xl bg-${stat.color}-500/10 border border-${stat.color}-500/20`}
            >
              <div className={`text-${stat.color}-400 mb-2`}>{stat.icon}</div>
              <div className={`text-2xl font-black text-${stat.color}-400`}>
                {stat.value}{stat.suffix || ''}
              </div>
              <div className="text-gray-500 text-xs mt-1">{stat.label}</div>
            </motion.div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Trend Chart */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="lg:col-span-2 bg-white/[0.03] border border-white/10 rounded-2xl p-6"
          >
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-white font-bold flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-violet-400" /> Weekly Trends
              </h3>
              <div className="flex items-center gap-4 text-xs">
                <div className="flex items-center gap-1"><div className="w-3 h-1 bg-violet-500 rounded" /> Meetings</div>
                <div className="flex items-center gap-1"><div className="w-3 h-1 bg-amber-500 rounded" /> Actions</div>
                <div className="flex items-center gap-1"><div className="w-3 h-1 bg-rose-500 rounded" /> Problems</div>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={trendData}>
                <defs>
                  <linearGradient id="violetGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="amberGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="week" tick={{ fill: '#6b7280', fontSize: 12 }} />
                <YAxis tick={{ fill: '#6b7280', fontSize: 12 }} />
                <Tooltip contentStyle={{ background: '#0a0a1a', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px', color: '#fff' }} />
                <Area type="monotone" dataKey="meetings" stroke="#8b5cf6" fill="url(#violetGrad)" strokeWidth={2} />
                <Area type="monotone" dataKey="actionItems" stroke="#f59e0b" fill="url(#amberGrad)" strokeWidth={2} />
                <Line type="monotone" dataKey="problems" stroke="#f43f5e" strokeWidth={2} dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          </motion.div>

          {/* Quick Stats */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-white/[0.03] border border-white/10 rounded-2xl p-6"
          >
            <h3 className="text-white font-bold mb-6 flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-violet-400" /> Problem Categories
            </h3>
            <div className="space-y-3">
              {[
                { name: 'Technical', count: 4, color: '#6366f1' },
                { name: 'Business', count: 2, color: '#f43f5e' },
                { name: 'UX/Design', count: 2, color: '#8b5cf6' },
                { name: 'Resource', count: 1, color: '#f59e0b' },
                { name: 'Marketing', count: 1, color: '#10b981' },
              ].map((cat, i) => (
                <div key={i}>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-300">{cat.name}</span>
                    <span className="text-gray-400">{cat.count}</span>
                  </div>
                  <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                    <motion.div
                      className="h-full rounded-full"
                      style={{ backgroundColor: cat.color }}
                      initial={{ width: 0 }}
                      animate={{ width: `${(cat.count / 4) * 100}%` }}
                      transition={{ duration: 0.8, delay: 0.5 + i * 0.1 }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Meeting List */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-white/[0.03] border border-white/10 rounded-2xl overflow-hidden"
        >
          <div className="p-6 border-b border-white/10 flex items-center justify-between">
            <h3 className="text-white font-bold text-lg flex items-center gap-2">
              <Calendar className="w-5 h-5 text-violet-400" /> All Meetings
            </h3>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white/5 border border-white/10 text-gray-400 text-sm">
                <Search className="w-4 h-4" />
                <span className="hidden sm:inline">Search...</span>
              </div>
            </div>
          </div>

          {meetings.length === 0 ? (
            <div className="p-12 text-center">
              <div className="w-16 h-16 rounded-2xl bg-violet-500/10 border border-violet-500/20 flex items-center justify-center mx-auto mb-4">
                <FileText className="w-8 h-8 text-violet-400" />
              </div>
              <p className="text-gray-400 mb-4">No meetings analyzed yet</p>
              <motion.button
                onClick={() => setCurrentPage('upload')}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-purple-600 text-white font-semibold text-sm"
                whileHover={{ scale: 1.05 }}
              >
                Analyze Your First Meeting
              </motion.button>
            </div>
          ) : (
            <div className="divide-y divide-white/5">
              {meetings.map((meeting, i) => (
                <motion.div
                  key={meeting.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.6 + i * 0.05 }}
                  onClick={() => handleMeetingClick(meeting)}
                  className="p-5 hover:bg-white/[0.02] transition-colors cursor-pointer group"
                >
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-xl bg-violet-500/15 border border-violet-500/20 flex items-center justify-center flex-shrink-0 text-violet-400">
                      {meeting.fileType.startsWith('audio') ? '🎵' :
                       meeting.fileType.startsWith('video') ? '🎬' :
                       meeting.fileType.includes('pdf') ? '📄' : '📝'}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2 flex-wrap">
                        <div>
                          <h4 className="text-white font-semibold group-hover:text-violet-300 transition-colors">{meeting.title}</h4>
                          <div className="flex flex-wrap items-center gap-3 mt-1 text-xs text-gray-500">
                            <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> {meeting.date}</span>
                            <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {meeting.duration}</span>
                            <span className="flex items-center gap-1"><Users className="w-3 h-3" /> {meeting.participants.length} people</span>
                            <span>{meeting.fileSize}</span>
                            {meeting.summary && (
                              <span className="text-base">{sentimentEmojis[meeting.summary.sentiment]}</span>
                            )}
                          </div>
                          {meeting.tags && (
                            <div className="flex gap-1 mt-2">
                              {meeting.tags.map(tag => (
                                <span key={tag} className="px-2 py-0.5 rounded-full bg-violet-500/10 border border-violet-500/20 text-violet-300 text-xs">{tag}</span>
                              ))}
                            </div>
                          )}
                        </div>
                        <div className="flex items-center gap-2 flex-shrink-0">
                          {meeting.summary && (
                            <div className="hidden md:flex items-center gap-2 text-xs">
                              <span className="px-2 py-0.5 rounded-full bg-rose-500/10 border border-rose-500/20 text-rose-300">
                                {meeting.summary.problems.length} problems
                              </span>
                              <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-300">
                                {meeting.summary.solutions.length} solutions
                              </span>
                              <span className="px-2 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300">
                                {meeting.summary.actionItems.length} actions
                              </span>
                            </div>
                          )}
                          <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold border ${statusColors[meeting.status]}`}>
                            {meeting.status}
                          </span>
                          {meeting.summary && (
                            <div className="hidden lg:flex items-center gap-1">
                              <div className="text-lg font-black text-violet-400">{meeting.summary.meetingScore}</div>
                              <div className="text-gray-500 text-xs">/100</div>
                            </div>
                          )}
                          <ChevronRight className="w-4 h-4 text-gray-600 group-hover:text-violet-400 transition-colors" />
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </motion.div>

        {/* Pending Action Items */}
        {pendingActions > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="mt-6 bg-white/[0.03] border border-amber-500/20 rounded-2xl p-6"
          >
            <h3 className="text-white font-bold text-lg mb-4 flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-amber-400" />
              Pending Action Items ({pendingActions})
            </h3>
            <div className="space-y-3">
              {completedMeetings
                .flatMap(m => (m.summary?.actionItems || []).map(a => ({ ...a, meetingTitle: m.title })))
                .filter(a => a.status === 'pending')
                .slice(0, 6)
                .map((item, i) => (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.8 + i * 0.05 }}
                    className="flex items-center gap-3 p-3 rounded-xl bg-white/[0.02] border border-white/5"
                  >
                    <div className="w-2 h-2 rounded-full bg-amber-400 flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <div className="text-white text-sm font-medium truncate">{item.task}</div>
                      <div className="text-gray-500 text-xs">
                        {item.assignee} • Due {item.deadline} • {(item as any).meetingTitle}
                      </div>
                    </div>
                    <span className={`px-2 py-0.5 rounded-full text-xs font-semibold border flex-shrink-0 ${
                      item.priority === 'high' ? 'text-red-400 bg-red-500/10 border-red-500/30' :
                      item.priority === 'medium' ? 'text-amber-400 bg-amber-500/10 border-amber-500/30' :
                      'text-green-400 bg-green-500/10 border-green-500/30'
                    }`}>
                      {item.priority}
                    </span>
                  </motion.div>
                ))}
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default DashboardPage;
