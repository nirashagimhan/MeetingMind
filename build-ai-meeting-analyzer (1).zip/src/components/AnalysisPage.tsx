import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Brain, CheckCircle, AlertTriangle, Target, Clock, User,
  ChevronDown, ChevronUp, ArrowRight, BarChart3, MessageSquare,
  FileText, TrendingUp, Shield, Lightbulb, Star, Flag,
  AlertCircle, Activity, Users, Zap, ThumbsUp, ThumbsDown
} from 'lucide-react';
import { Meeting, ActionItem, Problem, Solution, Decision, Risk } from '../types';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, RadialBarChart, RadialBar } from 'recharts';

interface AnalysisPageProps {
  meeting: Meeting;
  setCurrentPage: (page: string) => void;
}

const severityColor: Record<string, string> = {
  critical: 'text-red-400 bg-red-500/10 border-red-500/30',
  high: 'text-orange-400 bg-orange-500/10 border-orange-500/30',
  medium: 'text-amber-400 bg-amber-500/10 border-amber-500/30',
  low: 'text-green-400 bg-green-500/10 border-green-500/30',
};

const priorityColor: Record<string, string> = {
  high: 'text-red-400 bg-red-500/10 border-red-500/30',
  medium: 'text-amber-400 bg-amber-500/10 border-amber-500/30',
  low: 'text-green-400 bg-green-500/10 border-green-500/30',
};

const impactColor: Record<string, string> = {
  high: 'text-rose-400 bg-rose-500/10 border-rose-500/30',
  medium: 'text-violet-400 bg-violet-500/10 border-violet-500/30',
  low: 'text-blue-400 bg-blue-500/10 border-blue-500/30',
};

const TABS = ['Overview', 'Problems & Solutions', 'Action Items', 'Decisions', 'Analytics', 'Transcript', 'Risk Assessment'];

const AnalysisPage: React.FC<AnalysisPageProps> = ({ meeting, setCurrentPage }) => {
  const [activeTab, setActiveTab] = useState('Overview');
  const [expandedProblem, setExpandedProblem] = useState<string | null>(null);
  const [expandedSolution, setExpandedSolution] = useState<string | null>(null);

  const summary = meeting.summary;
  if (!summary) return null;

  const sentimentColors: Record<string, string> = {
    positive: 'text-emerald-400',
    negative: 'text-red-400',
    neutral: 'text-gray-400',
    mixed: 'text-amber-400',
  };

  const scoreColor = summary.meetingScore >= 80 ? 'text-emerald-400' : summary.meetingScore >= 60 ? 'text-amber-400' : 'text-red-400';

  return (
    <div className="min-h-screen bg-[#050510] pt-20">
      {/* Header */}
      <div className="bg-[#0a0a1a]/80 backdrop-blur-xl border-b border-white/10 sticky top-16 z-40">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
            <div>
              <h1 className="text-2xl font-black text-white">{meeting.title}</h1>
              <div className="flex flex-wrap items-center gap-4 mt-1 text-sm text-gray-400">
                <span className="flex items-center gap-1"><Clock className="w-4 h-4" /> {meeting.duration}</span>
                <span className="flex items-center gap-1"><Users className="w-4 h-4" /> {meeting.participants.length} participants</span>
                <span className="flex items-center gap-1"><FileText className="w-4 h-4" /> {meeting.fileName}</span>
                <span className={`flex items-center gap-1 font-medium ${sentimentColors[summary.sentiment]}`}>
                  {summary.sentiment === 'positive' ? <ThumbsUp className="w-4 h-4" /> : summary.sentiment === 'negative' ? <ThumbsDown className="w-4 h-4" /> : <Activity className="w-4 h-4" />}
                  {summary.sentiment.charAt(0).toUpperCase() + summary.sentiment.slice(1)} Sentiment
                </span>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className={`text-4xl font-black ${scoreColor}`}>{summary.meetingScore}</div>
              <div>
                <div className="text-white font-semibold text-sm">Meeting Score</div>
                <div className="w-24 h-1.5 bg-white/10 rounded-full mt-1">
                  <motion.div
                    className="h-full rounded-full bg-gradient-to-r from-violet-500 to-emerald-500"
                    initial={{ width: 0 }}
                    animate={{ width: `${summary.meetingScore}%` }}
                    transition={{ duration: 1, delay: 0.3 }}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Tab Bar */}
          <div className="flex gap-1 overflow-x-auto pb-1 scrollbar-hide">
            {TABS.map(tab => (
              <motion.button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${
                  activeTab === tab
                    ? 'bg-violet-600 text-white shadow-lg shadow-violet-500/20'
                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                }`}
                whileTap={{ scale: 0.95 }}
              >
                {tab}
              </motion.button>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <AnimatePresence mode="wait">
          {/* OVERVIEW */}
          {activeTab === 'Overview' && (
            <motion.div key="overview" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
              {/* Quick Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                {[
                  { label: 'Problems Found', value: summary.problems.length, color: 'rose', icon: <AlertCircle className="w-5 h-5" /> },
                  { label: 'Solutions', value: summary.solutions.length, color: 'emerald', icon: <Lightbulb className="w-5 h-5" /> },
                  { label: 'Action Items', value: summary.actionItems.length, color: 'amber', icon: <CheckCircle className="w-5 h-5" /> },
                  { label: 'Decisions', value: summary.decisions.length, color: 'violet', icon: <Flag className="w-5 h-5" /> },
                ].map((stat, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: i * 0.1 }}
                    className={`p-5 rounded-2xl bg-${stat.color}-500/10 border border-${stat.color}-500/20`}
                  >
                    <div className={`text-${stat.color}-400 mb-2`}>{stat.icon}</div>
                    <div className={`text-4xl font-black text-${stat.color}-400`}>{stat.value}</div>
                    <div className="text-gray-400 text-sm mt-1">{stat.label}</div>
                  </motion.div>
                ))}
              </div>

              {/* Summary */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className="lg:col-span-2 bg-white/[0.03] border border-white/10 rounded-2xl p-6"
                >
                  <h3 className="text-white font-bold text-lg mb-4 flex items-center gap-2">
                    <Brain className="w-5 h-5 text-violet-400" /> AI Summary
                  </h3>
                  <p className="text-gray-300 leading-relaxed mb-6">{summary.overview}</p>
                  <h4 className="text-white font-semibold mb-3">Key Points</h4>
                  <div className="space-y-2">
                    {summary.keyPoints.map((point, i) => (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.3 + i * 0.05 }}
                        className="flex items-start gap-2 text-gray-300 text-sm"
                      >
                        <div className="w-1.5 h-1.5 rounded-full bg-violet-400 mt-1.5 flex-shrink-0" />
                        {point}
                      </motion.div>
                    ))}
                  </div>
                </motion.div>

                <div className="space-y-4">
                  {/* Participants */}
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                    className="bg-white/[0.03] border border-white/10 rounded-2xl p-5"
                  >
                    <h3 className="text-white font-bold mb-4 flex items-center gap-2">
                      <Users className="w-4 h-4 text-violet-400" /> Participants
                    </h3>
                    <div className="space-y-3">
                      {summary.participants.map((p, i) => (
                        <div key={i} className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-violet-600 to-purple-600 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                            {p.avatar}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="text-white text-sm font-medium truncate">{p.name}</div>
                            <div className="text-gray-500 text-xs">{p.role}</div>
                          </div>
                          <div className={`text-xs ${sentimentColors[p.sentiment]}`}>
                            {p.speakingTime}%
                          </div>
                        </div>
                      ))}
                    </div>
                  </motion.div>

                  {/* Topics */}
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 }}
                    className="bg-white/[0.03] border border-white/10 rounded-2xl p-5"
                  >
                    <h3 className="text-white font-bold mb-4 flex items-center gap-2">
                      <BarChart3 className="w-4 h-4 text-violet-400" /> Topics
                    </h3>
                    <div className="space-y-2">
                      {summary.topics.map((topic, i) => (
                        <div key={i}>
                          <div className="flex justify-between text-sm mb-1">
                            <span className="text-gray-300">{topic.name}</span>
                            <span className="text-gray-400">{topic.percentage}%</span>
                          </div>
                          <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                            <motion.div
                              className="h-full rounded-full"
                              style={{ backgroundColor: topic.color }}
                              initial={{ width: 0 }}
                              animate={{ width: `${topic.percentage}%` }}
                              transition={{ duration: 0.8, delay: 0.4 + i * 0.1 }}
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                </div>
              </div>

              {/* Timeline */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="bg-white/[0.03] border border-white/10 rounded-2xl p-6"
              >
                <h3 className="text-white font-bold text-lg mb-6 flex items-center gap-2">
                  <Clock className="w-5 h-5 text-violet-400" /> Meeting Timeline
                </h3>
                <div className="relative">
                  <div className="absolute left-4 top-0 bottom-0 w-px bg-gradient-to-b from-violet-500/50 via-purple-500/30 to-transparent" />
                  <div className="space-y-4 ml-10">
                    {summary.timeline.map((item, i) => {
                      const typeConfig: Record<string, { color: string; dot: string }> = {
                        milestone: { color: 'text-violet-400', dot: 'bg-violet-500' },
                        decision: { color: 'text-emerald-400', dot: 'bg-emerald-500' },
                        action: { color: 'text-amber-400', dot: 'bg-amber-500' },
                        discussion: { color: 'text-blue-400', dot: 'bg-blue-500' },
                        concern: { color: 'text-rose-400', dot: 'bg-rose-500' },
                      };
                      const cfg = typeConfig[item.type] || typeConfig.discussion;
                      return (
                        <motion.div
                          key={i}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 0.6 + i * 0.08 }}
                          className="relative flex items-start gap-3"
                        >
                          <div className={`absolute -left-10 w-3 h-3 rounded-full ${cfg.dot} border-2 border-[#050510] top-1`} />
                          <span className="text-gray-500 text-sm font-mono w-12 flex-shrink-0">{item.time}</span>
                          <div>
                            <span className={`text-sm font-medium ${cfg.color}`}>{item.event}</span>
                            {item.speaker && <span className="text-gray-500 text-xs ml-2">— {item.speaker}</span>}
                          </div>
                        </motion.div>
                      );
                    })}
                  </div>
                </div>
              </motion.div>

              {/* Next Steps */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 }}
                className="mt-6 bg-violet-500/5 border border-violet-500/20 rounded-2xl p-6"
              >
                <h3 className="text-white font-bold text-lg mb-4 flex items-center gap-2">
                  <ArrowRight className="w-5 h-5 text-violet-400" /> Next Steps
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {summary.nextSteps.map((step, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.7 + i * 0.05 }}
                      className="flex items-start gap-2 text-gray-300 text-sm"
                    >
                      <div className="w-5 h-5 rounded-full bg-violet-500/20 border border-violet-500/40 flex items-center justify-center text-violet-400 text-xs font-bold flex-shrink-0 mt-0.5">
                        {i + 1}
                      </div>
                      {step}
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            </motion.div>
          )}

          {/* PROBLEMS & SOLUTIONS */}
          {activeTab === 'Problems & Solutions' && (
            <motion.div key="problems" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
              <div className="mb-6">
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-rose-500/10 border border-rose-500/30 text-rose-300 text-sm font-medium">
                  <AlertTriangle className="w-4 h-4" />
                  {summary.problems.length} Problems Identified — {summary.solutions.length} Solutions Generated
                </div>
              </div>

              <div className="space-y-6">
                {summary.problems.map((problem, i) => {
                  const solution = summary.solutions.find(s => s.problemId === problem.id);
                  return (
                    <motion.div
                      key={problem.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.1 }}
                      className="rounded-2xl overflow-hidden border border-white/10"
                    >
                      {/* Problem Header */}
                      <div
                        className="p-6 bg-rose-500/5 cursor-pointer"
                        onClick={() => setExpandedProblem(expandedProblem === problem.id ? null : problem.id)}
                      >
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex items-start gap-4 flex-1">
                            <div className="w-10 h-10 rounded-xl bg-rose-500/20 border border-rose-500/30 flex items-center justify-center flex-shrink-0">
                              <AlertCircle className="w-5 h-5 text-rose-400" />
                            </div>
                            <div className="flex-1">
                              <div className="flex flex-wrap items-center gap-2 mb-2">
                                <h4 className="text-white font-bold">{problem.title}</h4>
                                <span className={`px-2 py-0.5 rounded-full text-xs font-semibold border ${severityColor[problem.severity]}`}>
                                  {problem.severity.toUpperCase()}
                                </span>
                                <span className="px-2 py-0.5 rounded-full text-xs bg-white/5 border border-white/10 text-gray-400">{problem.category}</span>
                              </div>
                              <p className="text-gray-300 text-sm">{problem.description}</p>
                            </div>
                          </div>
                          {expandedProblem === problem.id ? <ChevronUp className="w-5 h-5 text-gray-400 flex-shrink-0" /> : <ChevronDown className="w-5 h-5 text-gray-400 flex-shrink-0" />}
                        </div>
                      </div>

                      {/* Problem Details */}
                      <AnimatePresence>
                        {expandedProblem === problem.id && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ duration: 0.3 }}
                            className="overflow-hidden"
                          >
                            <div className="p-6 border-t border-white/5 bg-rose-500/[0.02] grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div>
                                <div className="text-rose-400 text-xs font-semibold uppercase tracking-wider mb-2">Context</div>
                                <p className="text-gray-300 text-sm">{problem.context}</p>
                              </div>
                              <div>
                                <div className="text-rose-400 text-xs font-semibold uppercase tracking-wider mb-2">Impact</div>
                                <p className="text-gray-300 text-sm">{problem.impact}</p>
                              </div>
                              <div>
                                <div className="text-rose-400 text-xs font-semibold uppercase tracking-wider mb-2">Identified By</div>
                                <p className="text-gray-300 text-sm">{problem.identifiedBy}</p>
                              </div>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>

                      {/* Solution */}
                      {solution && (
                        <div className="border-t border-white/10">
                          <div
                            className="p-6 bg-emerald-500/5 cursor-pointer"
                            onClick={() => setExpandedSolution(expandedSolution === solution.id ? null : solution.id)}
                          >
                            <div className="flex items-start justify-between gap-4">
                              <div className="flex items-start gap-4 flex-1">
                                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center flex-shrink-0">
                                  <Lightbulb className="w-5 h-5 text-emerald-400" />
                                </div>
                                <div className="flex-1">
                                  <div className="flex flex-wrap items-center gap-2 mb-2">
                                    <h4 className="text-emerald-300 font-bold">✅ Solution: {solution.title}</h4>
                                    <span className={`px-2 py-0.5 rounded-full text-xs font-semibold border ${solution.feasibility === 'high' ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30' : 'text-amber-400 bg-amber-500/10 border-amber-500/30'}`}>
                                      {solution.feasibility.toUpperCase()} Feasibility
                                    </span>
                                    <span className="px-2 py-0.5 rounded-full text-xs bg-blue-500/10 border border-blue-500/20 text-blue-300">⏱ {solution.timeframe}</span>
                                  </div>
                                  <p className="text-gray-300 text-sm">{solution.description}</p>
                                  <div className="flex flex-wrap gap-3 mt-2 text-xs text-gray-400">
                                    <span className="flex items-center gap-1"><User className="w-3 h-3" /> Owner: {solution.owner}</span>
                                    <span className="flex items-center gap-1"><Target className="w-3 h-3" /> Resources: {solution.resources}</span>
                                  </div>
                                </div>
                              </div>
                              {expandedSolution === solution.id ? <ChevronUp className="w-5 h-5 text-gray-400 flex-shrink-0" /> : <ChevronDown className="w-5 h-5 text-gray-400 flex-shrink-0" />}
                            </div>
                          </div>
                          <AnimatePresence>
                            {expandedSolution === solution.id && (
                              <motion.div
                                initial={{ height: 0, opacity: 0 }}
                                animate={{ height: 'auto', opacity: 1 }}
                                exit={{ height: 0, opacity: 0 }}
                                transition={{ duration: 0.3 }}
                                className="overflow-hidden"
                              >
                                <div className="p-6 border-t border-white/5 bg-emerald-500/[0.02]">
                                  <div className="text-emerald-400 text-xs font-semibold uppercase tracking-wider mb-3">Implementation Steps</div>
                                  <div className="space-y-2">
                                    {solution.steps.map((step, si) => (
                                      <div key={si} className="flex items-start gap-3 text-sm text-gray-300">
                                        <div className="w-6 h-6 rounded-full bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 text-xs font-bold flex-shrink-0">
                                          {si + 1}
                                        </div>
                                        {step}
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </div>
                      )}
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>
          )}

          {/* ACTION ITEMS */}
          {activeTab === 'Action Items' && (
            <motion.div key="actions" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
              <div className="space-y-4">
                {summary.actionItems.map((item, i) => (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.08 }}
                    className="bg-white/[0.03] border border-white/10 rounded-2xl p-5 hover:border-violet-500/30 transition-colors"
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex items-start gap-3 flex-1">
                        <div className={`w-3 h-3 rounded-full mt-1.5 flex-shrink-0 ${
                          item.status === 'completed' ? 'bg-emerald-400' :
                          item.status === 'in-progress' ? 'bg-amber-400' : 'bg-gray-500'
                        }`} />
                        <div className="flex-1">
                          <p className={`font-medium mb-2 ${item.status === 'completed' ? 'line-through text-gray-500' : 'text-white'}`}>
                            {item.task}
                          </p>
                          <div className="flex flex-wrap gap-2">
                            <span className="flex items-center gap-1 text-xs text-gray-400">
                              <User className="w-3 h-3" /> {item.assignee}
                            </span>
                            <span className="flex items-center gap-1 text-xs text-gray-400">
                              <Clock className="w-3 h-3" /> {item.deadline}
                            </span>
                            <span className="text-xs px-2 py-0.5 rounded-full bg-violet-500/10 border border-violet-500/20 text-violet-300">{item.category}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <span className={`px-2.5 py-1 rounded-full text-xs font-semibold border whitespace-nowrap ${priorityColor[item.priority]}`}>
                          {item.priority.toUpperCase()}
                        </span>
                        <span className={`px-2.5 py-1 rounded-full text-xs font-semibold border whitespace-nowrap ${
                          item.status === 'completed' ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30' :
                          item.status === 'in-progress' ? 'text-amber-400 bg-amber-500/10 border-amber-500/30' :
                          'text-gray-400 bg-gray-500/10 border-gray-500/30'
                        }`}>
                          {item.status.replace('-', ' ').toUpperCase()}
                        </span>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}

          {/* DECISIONS */}
          {activeTab === 'Decisions' && (
            <motion.div key="decisions" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
              <div className="space-y-4">
                {summary.decisions.map((decision, i) => (
                  <motion.div
                    key={decision.id}
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.1 }}
                    className="bg-white/[0.03] border border-white/10 rounded-2xl p-6"
                  >
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-xl bg-violet-500/20 border border-violet-500/30 flex items-center justify-center flex-shrink-0">
                        <Flag className="w-5 h-5 text-violet-400" />
                      </div>
                      <div className="flex-1">
                        <div className="flex flex-wrap items-center gap-2 mb-3">
                          <h4 className="text-white font-bold text-lg">{decision.decision}</h4>
                          <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold border ${impactColor[decision.impact]}`}>
                            {decision.impact.toUpperCase()} Impact
                          </span>
                        </div>
                        <p className="text-gray-400 text-sm mb-3">{decision.rationale}</p>
                        <div className="flex gap-4 text-xs text-gray-500">
                          <span className="flex items-center gap-1"><User className="w-3 h-3" /> {decision.madeBy}</span>
                          {decision.timestamp && <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {decision.timestamp}</span>}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}

          {/* ANALYTICS */}
          {activeTab === 'Analytics' && (
            <motion.div key="analytics" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Topic Distribution */}
                <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-6">
                  <h3 className="text-white font-bold mb-6">Topic Distribution</h3>
                  <ResponsiveContainer width="100%" height={250}>
                    <PieChart>
                      <Pie data={summary.topics} dataKey="percentage" cx="50%" cy="50%" outerRadius={80} label={(props) => `${props.name} ${props.value}%`}>
                        {summary.topics.map((topic, i) => (
                          <Cell key={i} fill={topic.color} />
                        ))}
                      </Pie>
                      <Tooltip contentStyle={{ background: '#0a0a1a', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px', color: '#fff' }} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>

                {/* Speaking Time */}
                <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-6">
                  <h3 className="text-white font-bold mb-6">Speaking Time (min)</h3>
                  <ResponsiveContainer width="100%" height={250}>
                    <BarChart data={summary.participants}>
                      <XAxis dataKey="name" tick={{ fill: '#6b7280', fontSize: 11 }} tickFormatter={v => v.split(' ')[0]} />
                      <YAxis tick={{ fill: '#6b7280', fontSize: 11 }} />
                      <Tooltip contentStyle={{ background: '#0a0a1a', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px', color: '#fff' }} />
                      <Bar dataKey="speakingTime" fill="#8b5cf6" radius={[6, 6, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>

                {/* Participant Analysis */}
                <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-6">
                  <h3 className="text-white font-bold mb-4">Participant Analysis</h3>
                  <div className="space-y-4">
                    {summary.participants.map((p, i) => (
                      <div key={i}>
                        <div className="flex items-center gap-3 mb-2">
                          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-violet-600 to-purple-600 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                            {p.avatar}
                          </div>
                          <div className="flex-1">
                            <div className="flex justify-between items-center">
                              <span className="text-white text-sm font-medium">{p.name}</span>
                              <div className="flex gap-2 text-xs">
                                <span className="text-gray-400">{p.contributions} contributions</span>
                                <span className={sentimentColors[p.sentiment]}>●</span>
                              </div>
                            </div>
                            <div className="flex items-center gap-2 mt-1">
                              <div className="flex-1 h-1.5 bg-white/10 rounded-full overflow-hidden">
                                <motion.div
                                  className="h-full bg-gradient-to-r from-violet-500 to-purple-500 rounded-full"
                                  initial={{ width: 0 }}
                                  animate={{ width: `${p.speakingTime}%` }}
                                  transition={{ duration: 0.8, delay: 0.2 + i * 0.1 }}
                                />
                              </div>
                              <span className="text-gray-400 text-xs">{p.speakingTime}%</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Word Cloud */}
                <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-6">
                  <h3 className="text-white font-bold mb-6">Key Terms</h3>
                  <div className="flex flex-wrap gap-2 items-center justify-center">
                    {summary.wordCloud.map((word, i) => (
                      <motion.span
                        key={i}
                        initial={{ opacity: 0, scale: 0 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: i * 0.05 }}
                        className="px-3 py-1.5 rounded-full border font-semibold cursor-default hover:scale-110 transition-transform"
                        style={{
                          fontSize: `${Math.max(11, Math.min(22, word.value * 0.35))}px`,
                          color: word.color,
                          borderColor: `${word.color}40`,
                          backgroundColor: `${word.color}10`,
                        }}
                      >
                        {word.text}
                      </motion.span>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* TRANSCRIPT */}
          {activeTab === 'Transcript' && (
            <motion.div key="transcript" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
              <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-6">
                <h3 className="text-white font-bold text-lg mb-6 flex items-center gap-2">
                  <FileText className="w-5 h-5 text-violet-400" /> Full Transcript
                </h3>
                <div className="font-mono text-sm text-gray-300 leading-relaxed whitespace-pre-line bg-black/20 rounded-xl p-6 max-h-[600px] overflow-y-auto">
                  {meeting.transcript || 'Transcript not available for this file type. Audio/video files require transcription processing.'}
                </div>
              </div>
            </motion.div>
          )}

          {/* RISK ASSESSMENT */}
          {activeTab === 'Risk Assessment' && (
            <motion.div key="risks" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
              <div className="mb-6">
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-sm font-medium">
                  <Shield className="w-4 h-4" />
                  {summary.riskAssessment.length} Risks Identified
                </div>
              </div>
              <div className="space-y-4">
                {summary.riskAssessment.map((risk, i) => (
                  <motion.div
                    key={risk.id}
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.1 }}
                    className="bg-white/[0.03] border border-amber-500/20 rounded-2xl p-6"
                  >
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center flex-shrink-0">
                        <Shield className="w-5 h-5 text-amber-400" />
                      </div>
                      <div className="flex-1">
                        <div className="flex flex-wrap items-center gap-2 mb-3">
                          <h4 className="text-white font-bold">{risk.title}</h4>
                          <span className={`px-2 py-0.5 rounded-full text-xs font-semibold border ${severityColor[risk.probability]}`}>
                            Probability: {risk.probability.toUpperCase()}
                          </span>
                          <span className={`px-2 py-0.5 rounded-full text-xs font-semibold border ${impactColor[risk.impact]}`}>
                            Impact: {risk.impact.toUpperCase()}
                          </span>
                        </div>
                        <div className="mb-3">
                          <div className="text-xs font-semibold text-amber-400 uppercase tracking-wider mb-1">Mitigation Strategy</div>
                          <p className="text-gray-300 text-sm">{risk.mitigation}</p>
                        </div>
                        <div className="text-xs text-gray-500 flex items-center gap-1">
                          <User className="w-3 h-3" /> Owner: {risk.owner}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Chat Prompt */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="mt-10 p-6 rounded-2xl bg-gradient-to-r from-violet-600/10 to-purple-600/5 border border-violet-500/20"
        >
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-3">
              <MessageSquare className="w-6 h-6 text-violet-400" />
              <div>
                <div className="text-white font-semibold">Ask AI About This Meeting</div>
                <div className="text-gray-400 text-sm">Chat with your AI assistant about this analysis</div>
              </div>
            </div>
            <motion.button
              onClick={() => setCurrentPage('chat')}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-purple-600 text-white font-semibold text-sm"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Open AI Chat <ArrowRight className="w-4 h-4" />
            </motion.button>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default AnalysisPage;
