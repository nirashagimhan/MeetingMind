import React from 'react';
import { motion } from 'framer-motion';
import {
  TrendingUp, AlertCircle, CheckCircle, Lightbulb, Shield,
  Target, Users, BarChart3, Clock, Brain, ArrowUpRight, ArrowDownRight
} from 'lucide-react';
import { Meeting } from '../types';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, RadarChart, Radar, PolarGrid, PolarAngleAxis } from 'recharts';

interface InsightsPageProps {
  meetings: Meeting[];
  setCurrentPage: (page: string) => void;
  setSelectedMeeting: (meeting: Meeting) => void;
}

const InsightsPage: React.FC<InsightsPageProps> = ({ meetings, setCurrentPage, setSelectedMeeting }) => {
  const completed = meetings.filter(m => m.status === 'completed' && m.summary);
  const allProblems = completed.flatMap(m => m.summary!.problems);
  const allSolutions = completed.flatMap(m => m.summary!.solutions);
  const allActions = completed.flatMap(m => m.summary!.actionItems);
  const allDecisions = completed.flatMap(m => m.summary!.decisions);
  const allRisks = completed.flatMap(m => m.summary!.riskAssessment);

  const criticalProblems = allProblems.filter(p => p.severity === 'critical');
  const highProblems = allProblems.filter(p => p.severity === 'high');
  const pendingActions = allActions.filter(a => a.status === 'pending');

  const severityData = [
    { name: 'Critical', value: criticalProblems.length, color: '#f43f5e' },
    { name: 'High', value: highProblems.length, color: '#f97316' },
    { name: 'Medium', value: allProblems.filter(p => p.severity === 'medium').length, color: '#f59e0b' },
    { name: 'Low', value: allProblems.filter(p => p.severity === 'low').length, color: '#22c55e' },
  ].filter(d => d.value > 0);

  const categoryData = [...new Set(allProblems.map(p => p.category))].map(cat => ({
    category: cat,
    count: allProblems.filter(p => p.category === cat).length,
  }));

  const feasibilityData = [
    { name: 'High Feasibility', value: allSolutions.filter(s => s.feasibility === 'high').length, color: '#22c55e' },
    { name: 'Medium', value: allSolutions.filter(s => s.feasibility === 'medium').length, color: '#f59e0b' },
    { name: 'Low', value: allSolutions.filter(s => s.feasibility === 'low').length, color: '#f43f5e' },
  ].filter(d => d.value > 0);

  const radarData = [
    { subject: 'Action Clarity', A: 80 },
    { subject: 'Decision Quality', A: 75 },
    { subject: 'Problem Detection', A: 92 },
    { subject: 'Participation', A: 65 },
    { subject: 'Risk Awareness', A: 70 },
    { subject: 'Follow-through', A: 58 },
  ];

  const actionsByPriority = [
    { priority: 'High', count: allActions.filter(a => a.priority === 'high').length },
    { priority: 'Medium', count: allActions.filter(a => a.priority === 'medium').length },
    { priority: 'Low', count: allActions.filter(a => a.priority === 'low').length },
  ];

  const insights = [
    {
      type: 'critical',
      icon: <AlertCircle className="w-5 h-5" />,
      title: 'Critical Issues Require Immediate Attention',
      description: `${criticalProblems.length} critical problems identified: ${criticalProblems.map(p => p.title).join(', ')}. These need immediate escalation.`,
      action: 'View Problems',
      color: 'rose',
    },
    {
      type: 'warning',
      icon: <Clock className="w-5 h-5" />,
      title: `${pendingActions.length} Action Items Still Pending`,
      description: `${pendingActions.filter(a => a.priority === 'high').length} high-priority tasks are unassigned or overdue. Risk of delivery delays increasing.`,
      action: 'View Actions',
      color: 'amber',
    },
    {
      type: 'positive',
      icon: <Lightbulb className="w-5 h-5" />,
      title: 'High Solution Feasibility Rate',
      description: `${Math.round((allSolutions.filter(s => s.feasibility === 'high').length / Math.max(allSolutions.length, 1)) * 100)}% of generated solutions are high feasibility — implementation should be straightforward.`,
      action: 'View Solutions',
      color: 'emerald',
    },
    {
      type: 'info',
      icon: <Shield className="w-5 h-5" />,
      title: `${allRisks.length} Risks Identified Across Meetings`,
      description: `${allRisks.filter(r => r.probability === 'high').length} high-probability risks need immediate mitigation planning to prevent impact.`,
      action: 'View Risks',
      color: 'violet',
    },
  ];

  return (
    <div className="min-h-screen bg-[#050510] pt-20 px-4 pb-12">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="py-8"
        >
          <h1 className="text-3xl font-black text-white flex items-center gap-3">
            <Brain className="w-8 h-8 text-violet-400" />
            Meeting Intelligence Insights
          </h1>
          <p className="text-gray-400 mt-2">Synthesized intelligence from {completed.length} analyzed meetings</p>
        </motion.div>

        {/* AI Insights */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          {insights.map((insight, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className={`p-5 rounded-2xl bg-${insight.color}-500/5 border border-${insight.color}-500/20 hover:border-${insight.color}-500/40 transition-colors`}
            >
              <div className="flex items-start gap-3">
                <div className={`w-10 h-10 rounded-xl bg-${insight.color}-500/20 flex items-center justify-center text-${insight.color}-400 flex-shrink-0`}>
                  {insight.icon}
                </div>
                <div className="flex-1">
                  <h3 className={`text-${insight.color}-300 font-bold mb-1`}>{insight.title}</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">{insight.description}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Problem Severity */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-white/[0.03] border border-white/10 rounded-2xl p-6"
          >
            <h3 className="text-white font-bold mb-4 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400" /> Problem Severity
            </h3>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={severityData} dataKey="value" cx="50%" cy="50%" outerRadius={70} label={({ name, value }) => `${name}: ${value}`}>
                  {severityData.map((entry, i) => (
                    <Cell key={i} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ background: '#0a0a1a', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px', color: '#fff' }} />
              </PieChart>
            </ResponsiveContainer>
          </motion.div>

          {/* Action Items by Priority */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-white/[0.03] border border-white/10 rounded-2xl p-6"
          >
            <h3 className="text-white font-bold mb-4 flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-amber-400" /> Actions by Priority
            </h3>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={actionsByPriority}>
                <XAxis dataKey="priority" tick={{ fill: '#6b7280', fontSize: 12 }} />
                <YAxis tick={{ fill: '#6b7280', fontSize: 12 }} />
                <Tooltip contentStyle={{ background: '#0a0a1a', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px', color: '#fff' }} />
                <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                  {actionsByPriority.map((_, i) => (
                    <Cell key={i} fill={['#f43f5e', '#f59e0b', '#22c55e'][i]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </motion.div>

          {/* Meeting Effectiveness Radar */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="bg-white/[0.03] border border-white/10 rounded-2xl p-6"
          >
            <h3 className="text-white font-bold mb-4 flex items-center gap-2">
              <Target className="w-4 h-4 text-violet-400" /> Meeting Effectiveness
            </h3>
            <ResponsiveContainer width="100%" height={200}>
              <RadarChart data={radarData}>
                <PolarGrid stroke="#ffffff15" />
                <PolarAngleAxis dataKey="subject" tick={{ fill: '#6b7280', fontSize: 10 }} />
                <Radar name="Score" dataKey="A" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.2} />
                <Tooltip contentStyle={{ background: '#0a0a1a', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px', color: '#fff' }} />
              </RadarChart>
            </ResponsiveContainer>
          </motion.div>
        </div>

        {/* Problem Categories */}
        {categoryData.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="bg-white/[0.03] border border-white/10 rounded-2xl p-6 mb-6"
          >
            <h3 className="text-white font-bold text-lg mb-4 flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-violet-400" /> Problem Categories
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {categoryData.map((cat, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.7 + i * 0.05 }}
                  className="p-4 rounded-xl bg-white/[0.02] border border-white/10 text-center hover:border-violet-500/30 transition-colors"
                >
                  <div className="text-3xl font-black text-white mb-1">{cat.count}</div>
                  <div className="text-gray-400 text-sm">{cat.category}</div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Top Problems with Solutions Summary */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="bg-white/[0.03] border border-white/10 rounded-2xl p-6 mb-6"
        >
          <h3 className="text-white font-bold text-lg mb-6 flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-rose-400" />
            All Problems & Solutions Summary
          </h3>
          <div className="space-y-3">
            {allProblems.map((problem, i) => {
              const solution = allSolutions.find(s => s.problemId === problem.id);
              return (
                <motion.div
                  key={problem.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.8 + i * 0.05 }}
                  className="grid grid-cols-1 md:grid-cols-2 gap-3 p-4 rounded-xl bg-white/[0.02] border border-white/5"
                >
                  <div className="flex items-start gap-3">
                    <div className={`w-2 h-2 rounded-full mt-2 flex-shrink-0 ${
                      problem.severity === 'critical' ? 'bg-red-500' :
                      problem.severity === 'high' ? 'bg-orange-500' :
                      problem.severity === 'medium' ? 'bg-amber-500' : 'bg-green-500'
                    }`} />
                    <div>
                      <div className="text-white text-sm font-semibold">{problem.title}</div>
                      <div className="text-gray-500 text-xs">{problem.category} • {problem.severity}</div>
                    </div>
                  </div>
                  {solution ? (
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                      <div>
                        <div className="text-emerald-300 text-sm font-semibold">{solution.title}</div>
                        <div className="text-gray-500 text-xs">{solution.owner} • {solution.timeframe}</div>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 text-gray-500 text-sm">
                      <div className="w-4 h-4 rounded-full border border-gray-600" />
                      No solution assigned yet
                    </div>
                  )}
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Key Recommendations */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9 }}
          className="bg-gradient-to-br from-violet-600/10 to-purple-600/5 border border-violet-500/20 rounded-2xl p-6"
        >
          <h3 className="text-white font-bold text-lg mb-4 flex items-center gap-2">
            <Brain className="w-5 h-5 text-violet-400" /> AI Recommendations
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              { num: '01', title: 'Address Critical API Performance Immediately', desc: 'The 2.3s API response time is actively impacting enterprise clients. Redis caching should be deployed this week.', urgency: 'Immediate' },
              { num: '02', title: 'Accelerate Mobile Crash Resolution', desc: '2.3% crash rate will cause app store rating damage. Allocate dedicated sprint for crash fixes before launch.', urgency: 'This Week' },
              { num: '03', title: 'Fast-track Senior Engineer Hiring', desc: 'Team capacity is the root cause of multiple delays. Begin interviews immediately, consider contractors as bridge.', urgency: 'This Week' },
              { num: '04', title: 'Launch Customer Success Overhaul', desc: '8% churn is 60% above industry average. Customer success program will have highest ROI of any initiative.', urgency: 'This Month' },
            ].map((rec, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1 + i * 0.1 }}
                className="p-4 rounded-xl bg-white/[0.03] border border-white/10"
              >
                <div className="flex items-start gap-3">
                  <span className="text-violet-400/40 text-3xl font-black leading-none">{rec.num}</span>
                  <div>
                    <div className="text-white font-semibold text-sm mb-1">{rec.title}</div>
                    <div className="text-gray-400 text-xs leading-relaxed mb-2">{rec.desc}</div>
                    <span className="px-2 py-0.5 rounded-full bg-violet-500/15 border border-violet-500/30 text-violet-300 text-xs font-medium">
                      ⏰ {rec.urgency}
                    </span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default InsightsPage;
