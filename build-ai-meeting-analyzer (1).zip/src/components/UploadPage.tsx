import React, { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useDropzone } from 'react-dropzone';
import {
  Upload, FileText, FileAudio, FileVideo, Volume2, CheckCircle,
  X, Loader2, Sparkles, Brain, AlertCircle, File, ArrowRight
} from 'lucide-react';
import { Meeting } from '../types';
import { generateAnalysis } from '../data/mockDatabase';

interface UploadPageProps {
  onMeetingAnalyzed: (meeting: Meeting) => void;
  setCurrentPage: (page: string) => void;
  setSelectedMeeting: (meeting: Meeting) => void;
}

const ACCEPTED_TYPES: Record<string, string[]> = {
  'audio/mpeg': ['.mp3'],
  'audio/mp4': ['.m4a'],
  'audio/wav': ['.wav'],
  'audio/ogg': ['.ogg'],
  'video/mpeg': ['.mpeg', '.mpg'],
  'video/mp4': ['.mp4'],
  'video/quicktime': ['.mov'],
  'video/x-msvideo': ['.avi'],
  'application/pdf': ['.pdf'],
  'application/msword': ['.doc'],
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
  'text/plain': ['.txt'],
};

const getFileIcon = (type: string) => {
  if (type.startsWith('audio/')) return <FileAudio className="w-8 h-8 text-violet-400" />;
  if (type.startsWith('video/')) return <FileVideo className="w-8 h-8 text-blue-400" />;
  if (type === 'application/pdf') return <FileText className="w-8 h-8 text-rose-400" />;
  if (type.includes('word')) return <FileText className="w-8 h-8 text-indigo-400" />;
  return <File className="w-8 h-8 text-gray-400" />;
};

const getFileColor = (type: string) => {
  if (type.startsWith('audio/')) return 'from-violet-600/20 to-purple-600/10 border-violet-500/30';
  if (type.startsWith('video/')) return 'from-blue-600/20 to-cyan-600/10 border-blue-500/30';
  if (type === 'application/pdf') return 'from-rose-600/20 to-pink-600/10 border-rose-500/30';
  if (type.includes('word')) return 'from-indigo-600/20 to-blue-600/10 border-indigo-500/30';
  return 'from-gray-600/20 to-gray-600/10 border-gray-500/30';
};

interface ProcessingStep {
  id: string;
  label: string;
  status: 'pending' | 'active' | 'done';
}

const UploadPage: React.FC<UploadPageProps> = ({ onMeetingAnalyzed, setCurrentPage, setSelectedMeeting }) => {
  const [files, setFiles] = useState<File[]>([]);
  const [processing, setProcessing] = useState(false);
  const [processingSteps, setProcessingSteps] = useState<ProcessingStep[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [completed, setCompleted] = useState<Meeting | null>(null);

  const onDrop = useCallback((accepted: File[], rejected: any[]) => {
    setError(null);
    if (rejected.length > 0) {
      setError('Some files were rejected. Please check supported formats.');
    }
    setFiles(prev => [...prev, ...accepted].slice(0, 5));
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: ACCEPTED_TYPES,
    maxFiles: 5,
    maxSize: 500 * 1024 * 1024,
  });

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const formatSize = (bytes: number) => {
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const simulateProcessing = async (file: File) => {
    const steps: ProcessingStep[] = [
      { id: '1', label: 'Parsing file format & metadata', status: 'pending' },
      { id: '2', label: 'Extracting audio/text content', status: 'pending' },
      { id: '3', label: 'AI transcription & speaker detection', status: 'pending' },
      { id: '4', label: 'Analyzing topics & key points', status: 'pending' },
      { id: '5', label: 'Identifying problems & generating solutions', status: 'pending' },
      { id: '6', label: 'Extracting action items & decisions', status: 'pending' },
      { id: '7', label: 'Running sentiment & risk analysis', status: 'pending' },
      { id: '8', label: 'Building knowledge base entry', status: 'pending' },
    ];

    setProcessingSteps(steps);

    for (let i = 0; i < steps.length; i++) {
      await new Promise(r => setTimeout(r, 600 + Math.random() * 400));
      setProcessingSteps(prev => prev.map((s, idx) => ({
        ...s,
        status: idx < i ? 'done' : idx === i ? 'active' : 'pending'
      })));
    }

    await new Promise(r => setTimeout(r, 500));
    setProcessingSteps(prev => prev.map(s => ({ ...s, status: 'done' })));
  };

  const handleAnalyze = async () => {
    if (files.length === 0) return;
    setProcessing(true);
    setError(null);

    const file = files[0];
    await simulateProcessing(file);

    const result = generateAnalysis(file.name, file.type);
    result.fileSize = formatSize(file.size);

    onMeetingAnalyzed(result);
    setCompleted(result);
    setProcessing(false);
  };

  const handleViewResults = () => {
    if (completed) {
      setSelectedMeeting(completed);
      setCurrentPage('analysis');
    }
  };

  if (completed && !processing) {
    return (
      <div className="min-h-screen bg-[#050510] pt-24 px-4 pb-12">
        <div className="max-w-2xl mx-auto text-center">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', stiffness: 200 }}
          >
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center mx-auto mb-8 shadow-2xl shadow-emerald-500/30">
              <CheckCircle className="w-14 h-14 text-white" />
            </div>
          </motion.div>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="text-4xl font-black text-white mb-4"
          >
            Analysis Complete! 🎉
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="text-gray-400 text-lg mb-8"
          >
            Your file has been fully analyzed. Found <span className="text-rose-400 font-bold">{completed.summary?.problems.length} problems</span> with <span className="text-emerald-400 font-bold">{completed.summary?.solutions.length} solutions</span>, {completed.summary?.actionItems.length} action items and {completed.summary?.decisions.length} decisions.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8"
          >
            {[
              { label: 'Problems', value: completed.summary?.problems.length, color: 'rose' },
              { label: 'Solutions', value: completed.summary?.solutions.length, color: 'emerald' },
              { label: 'Action Items', value: completed.summary?.actionItems.length, color: 'amber' },
              { label: 'Decisions', value: completed.summary?.decisions.length, color: 'violet' },
            ].map((stat, i) => (
              <div key={i} className={`p-4 rounded-2xl bg-${stat.color}-500/10 border border-${stat.color}-500/20`}>
                <div className={`text-3xl font-black text-${stat.color}-400`}>{stat.value}</div>
                <div className="text-gray-400 text-sm">{stat.label}</div>
              </div>
            ))}
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <motion.button
              onClick={handleViewResults}
              className="flex items-center justify-center gap-2 px-8 py-4 rounded-2xl bg-gradient-to-r from-violet-600 to-purple-600 text-white font-bold text-lg shadow-xl shadow-purple-500/30"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.98 }}
            >
              <Brain className="w-5 h-5" />
              View Full Analysis
              <ArrowRight className="w-5 h-5" />
            </motion.button>
            <motion.button
              onClick={() => { setCompleted(null); setFiles([]); setProcessingSteps([]); }}
              className="flex items-center justify-center gap-2 px-8 py-4 rounded-2xl bg-white/5 border border-white/15 text-white font-semibold text-lg"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.98 }}
            >
              <Upload className="w-5 h-5" />
              Analyze Another File
            </motion.button>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#050510] pt-24 px-4 pb-12">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-violet-500/10 border border-violet-500/30 text-violet-300 text-sm font-medium mb-4">
            <Sparkles className="w-4 h-4" />
            AI-Powered Meeting Analysis
          </div>
          <h1 className="text-4xl md:text-5xl font-black text-white mb-4">
            Upload Your Meeting File
          </h1>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Upload audio recordings, videos, or documents. Our AI will analyze everything
            and identify every problem with concrete solutions.
          </p>
        </motion.div>

        {!processing ? (
          <>
            {/* Dropzone */}
            <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
            <div
              {...getRootProps()}
              className={`relative border-2 border-dashed rounded-3xl p-12 text-center cursor-pointer transition-all duration-300 ${
                isDragActive
                  ? 'border-violet-500 bg-violet-500/10 scale-[1.02]'
                  : 'border-white/20 bg-white/[0.02] hover:border-violet-500/50 hover:bg-white/[0.04]'
              }`}
            >
              <input {...getInputProps()} />
              <div className="pointer-events-none">
                <motion.div
                  animate={isDragActive ? { scale: [1, 1.1, 1], rotate: [0, 5, -5, 0] } : {}}
                  transition={{ duration: 0.5, repeat: isDragActive ? Infinity : 0 }}
                  className="w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-violet-600 to-purple-600 flex items-center justify-center shadow-2xl shadow-violet-500/30"
                >
                  <Upload className="w-10 h-10 text-white" />
                </motion.div>
                <h3 className="text-2xl font-bold text-white mb-2">
                  {isDragActive ? 'Drop it here!' : 'Drag & drop your files'}
                </h3>
                <p className="text-gray-400 mb-6">
                  or <span className="text-violet-400 underline">browse to upload</span>
                </p>

                {/* Supported formats */}
                <div className="flex flex-wrap justify-center gap-2">
                  {[
                    { label: 'MP3', icon: <Volume2 className="w-3 h-3" />, color: 'text-violet-400 bg-violet-500/10 border-violet-500/30' },
                    { label: 'MPEG', icon: <FileVideo className="w-3 h-3" />, color: 'text-blue-400 bg-blue-500/10 border-blue-500/30' },
                    { label: 'MP4', icon: <FileVideo className="w-3 h-3" />, color: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/30' },
                    { label: 'WAV', icon: <Volume2 className="w-3 h-3" />, color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30' },
                    { label: 'M4A', icon: <FileAudio className="w-3 h-3" />, color: 'text-amber-400 bg-amber-500/10 border-amber-500/30' },
                    { label: 'MOV', icon: <FileVideo className="w-3 h-3" />, color: 'text-orange-400 bg-orange-500/10 border-orange-500/30' },
                    { label: 'PDF', icon: <FileText className="w-3 h-3" />, color: 'text-rose-400 bg-rose-500/10 border-rose-500/30' },
                    { label: 'DOC', icon: <FileText className="w-3 h-3" />, color: 'text-indigo-400 bg-indigo-500/10 border-indigo-500/30' },
                    { label: 'DOCX', icon: <FileText className="w-3 h-3" />, color: 'text-purple-400 bg-purple-500/10 border-purple-500/30' },
                    { label: 'TXT', icon: <FileText className="w-3 h-3" />, color: 'text-gray-400 bg-gray-500/10 border-gray-500/30' },
                  ].map(f => (
                    <span key={f.label} className={`flex items-center gap-1 px-2.5 py-1 rounded-lg border text-xs font-medium ${f.color}`}>
                      {f.icon}{f.label}
                    </span>
                  ))}
                </div>
                <p className="text-gray-500 text-sm mt-4">Max 500MB per file • Up to 5 files</p>
              </div>
            </div>
            </motion.div>

            {/* Error */}
            <AnimatePresence>
              {error && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="mt-4 flex items-center gap-2 p-4 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400"
                >
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  {error}
                </motion.div>
              )}
            </AnimatePresence>

            {/* File List */}
            <AnimatePresence>
              {files.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-6 space-y-3"
                >
                  {files.map((file, i) => (
                    <motion.div
                      key={`${file.name}-${i}`}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 20 }}
                      transition={{ delay: i * 0.05 }}
                      className={`flex items-center gap-4 p-4 rounded-2xl bg-gradient-to-r ${getFileColor(file.type)} border`}
                    >
                      {getFileIcon(file.type)}
                      <div className="flex-1 min-w-0">
                        <div className="text-white font-medium truncate">{file.name}</div>
                        <div className="text-gray-400 text-sm">{formatSize(file.size)} • {file.type || 'Unknown type'}</div>
                      </div>
                      <motion.button
                        onClick={() => removeFile(i)}
                        className="w-8 h-8 rounded-lg bg-white/10 hover:bg-red-500/20 hover:text-red-400 flex items-center justify-center text-gray-400 transition-colors"
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                      >
                        <X className="w-4 h-4" />
                      </motion.button>
                    </motion.div>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>

            {/* Analyze Button */}
            {files.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-6 text-center"
              >
                <motion.button
                  onClick={handleAnalyze}
                  className="inline-flex items-center gap-3 px-10 py-5 rounded-2xl bg-gradient-to-r from-violet-600 to-purple-600 text-white font-bold text-xl shadow-2xl shadow-purple-500/30"
                  whileHover={{ scale: 1.05, y: -2 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Brain className="w-6 h-6" />
                  Analyze with AI
                  <Sparkles className="w-6 h-6" />
                </motion.button>
                <p className="text-gray-500 text-sm mt-3">Estimated time: 30-60 seconds</p>
              </motion.div>
            )}

            {/* Features hint */}
            {files.length === 0 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="mt-10 grid grid-cols-1 md:grid-cols-3 gap-4"
              >
                {[
                  { title: 'Full Transcription', desc: 'Word-for-word transcript with speaker identification', icon: '📝' },
                  { title: 'Problem Analysis', desc: 'Every problem identified with severity and impact assessment', icon: '🔍' },
                  { title: 'Solution Generation', desc: 'AI-generated concrete solutions with steps and owners', icon: '💡' },
                ].map((hint, i) => (
                  <div key={i} className="p-5 rounded-2xl bg-white/[0.02] border border-white/10 text-center">
                    <div className="text-3xl mb-3">{hint.icon}</div>
                    <div className="text-white font-semibold mb-1">{hint.title}</div>
                    <div className="text-gray-400 text-sm">{hint.desc}</div>
                  </div>
                ))}
              </motion.div>
            )}
          </>
        ) : (
          /* Processing View */
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white/[0.03] border border-white/10 rounded-3xl p-8"
          >
            <div className="flex items-center gap-4 mb-8">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
                className="w-14 h-14 rounded-xl bg-gradient-to-br from-violet-600 to-purple-600 flex items-center justify-center shadow-lg shadow-violet-500/30"
              >
                <Brain className="w-8 h-8 text-white" />
              </motion.div>
              <div>
                <h3 className="text-2xl font-bold text-white">AI Analyzing Your File</h3>
                <p className="text-gray-400">{files[0]?.name}</p>
              </div>
            </div>

            <div className="space-y-3">
              {processingSteps.map((step, i) => (
                <motion.div
                  key={step.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className={`flex items-center gap-3 p-4 rounded-xl transition-all duration-500 ${
                    step.status === 'active' ? 'bg-violet-500/10 border border-violet-500/30' :
                    step.status === 'done' ? 'bg-emerald-500/5 border border-emerald-500/20' :
                    'bg-white/[0.02] border border-white/5'
                  }`}
                >
                  <div className="flex-shrink-0">
                    {step.status === 'done' ? (
                      <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }}>
                        <CheckCircle className="w-5 h-5 text-emerald-400" />
                      </motion.div>
                    ) : step.status === 'active' ? (
                      <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}>
                        <Loader2 className="w-5 h-5 text-violet-400" />
                      </motion.div>
                    ) : (
                      <div className="w-5 h-5 rounded-full border-2 border-white/20" />
                    )}
                  </div>
                  <span className={`text-sm font-medium ${
                    step.status === 'done' ? 'text-emerald-400' :
                    step.status === 'active' ? 'text-violet-300' :
                    'text-gray-500'
                  }`}>
                    {step.label}
                  </span>
                  {step.status === 'active' && (
                    <motion.div
                      className="ml-auto flex gap-1"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                    >
                      {[0, 1, 2].map(dot => (
                        <motion.div
                          key={dot}
                          className="w-1.5 h-1.5 bg-violet-400 rounded-full"
                          animate={{ y: [0, -4, 0] }}
                          transition={{ duration: 0.6, repeat: Infinity, delay: dot * 0.2 }}
                        />
                      ))}
                    </motion.div>
                  )}
                </motion.div>
              ))}
            </div>

            {/* Progress bar */}
            <div className="mt-6">
              <div className="flex justify-between text-sm text-gray-400 mb-2">
                <span>Processing...</span>
                <span>{Math.round((processingSteps.filter(s => s.status === 'done').length / processingSteps.length) * 100)}%</span>
              </div>
              <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-violet-500 to-purple-500 rounded-full"
                  animate={{ width: `${(processingSteps.filter(s => s.status === 'done').length / Math.max(processingSteps.length, 1)) * 100}%` }}
                  transition={{ duration: 0.5 }}
                />
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default UploadPage;
