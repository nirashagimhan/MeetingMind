import React, { useEffect, useRef } from 'react';
import { motion, useAnimation, useInView } from 'framer-motion';
import {
  Brain, Upload, FileText, Mic, Zap, CheckCircle, ArrowRight,
  Star, Users, BarChart3, MessageSquare, Shield, Globe,
  PlayCircle, Sparkles, TrendingUp, Clock, Target, Award,
  ChevronRight, Volume2, FileVideo, FileAudio
} from 'lucide-react';

interface HomePageProps {
  setCurrentPage: (page: string) => void;
}

const AnimatedCounter: React.FC<{ end: number; suffix?: string; duration?: number }> = ({ end, suffix = '', duration = 2 }) => {
  const [count, setCount] = React.useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true });

  useEffect(() => {
    if (inView) {
      let start = 0;
      const increment = end / (duration * 60);
      const timer = setInterval(() => {
        start += increment;
        if (start >= end) {
          setCount(end);
          clearInterval(timer);
        } else {
          setCount(Math.floor(start));
        }
      }, 1000 / 60);
      return () => clearInterval(timer);
    }
  }, [inView, end, duration]);

  return <span ref={ref}>{count.toLocaleString()}{suffix}</span>;
};

const FeatureCard: React.FC<{ icon: React.ReactNode; title: string; desc: string; color: string; delay: number }> = ({ icon, title, desc, color, delay }) => {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-50px' });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 40 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay }}
      whileHover={{ y: -8, scale: 1.02 }}
      className="relative group"
    >
      <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-violet-600/10 to-purple-600/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      <div className="relative bg-white/[0.03] border border-white/10 rounded-2xl p-6 h-full hover:border-violet-500/30 transition-all duration-300">
        <div className={`w-12 h-12 rounded-xl ${color} flex items-center justify-center mb-4 shadow-lg`}>
          {icon}
        </div>
        <h3 className="text-lg font-semibold text-white mb-2">{title}</h3>
        <p className="text-gray-400 text-sm leading-relaxed">{desc}</p>
      </div>
    </motion.div>
  );
};

const HomePage: React.FC<HomePageProps> = ({ setCurrentPage }) => {
  const heroRef = useRef(null);

  const features = [
    { icon: <Brain className="w-6 h-6 text-white" />, title: 'AI-Powered Analysis', desc: 'Advanced NLP extracts meaning, decisions, action items and insights from any meeting format automatically.', color: 'bg-gradient-to-br from-violet-600 to-purple-600', delay: 0 },
    { icon: <Target className="w-6 h-6 text-white" />, title: 'Problem & Solution Finder', desc: 'Automatically identifies every problem discussed and generates concrete, actionable solutions with owners and timelines.', color: 'bg-gradient-to-br from-rose-600 to-pink-600', delay: 0.1 },
    { icon: <FileText className="w-6 h-6 text-white" />, title: 'Multi-Format Support', desc: 'Upload MP3, MPEG, MP4, PDF, DOC, DOCX, WAV, M4A files. Our AI handles any format you throw at it.', color: 'bg-gradient-to-br from-blue-600 to-cyan-600', delay: 0.2 },
    { icon: <MessageSquare className="w-6 h-6 text-white" />, title: 'Smart AI Chat', desc: 'Chat with your entire meeting knowledge base. Ask anything about past meetings and get instant, accurate answers.', color: 'bg-gradient-to-br from-emerald-600 to-teal-600', delay: 0.3 },
    { icon: <BarChart3 className="w-6 h-6 text-white" />, title: 'Visual Analytics', desc: 'Beautiful charts showing speaking time, topic coverage, sentiment analysis, participation metrics and trends.', color: 'bg-gradient-to-br from-amber-600 to-orange-600', delay: 0.4 },
    { icon: <CheckCircle className="w-6 h-6 text-white" />, title: 'Action Item Tracking', desc: 'Every action item extracted, assigned, prioritized and tracked. Never let a follow-up slip through the cracks.', color: 'bg-gradient-to-br from-indigo-600 to-violet-600', delay: 0.5 },
    { icon: <TrendingUp className="w-6 h-6 text-white" />, title: 'Risk Assessment', desc: 'AI identifies risks mentioned in meetings, assesses probability and impact, and suggests mitigation strategies.', color: 'bg-gradient-to-br from-red-600 to-rose-600', delay: 0.6 },
    { icon: <Globe className="w-6 h-6 text-white" />, title: 'Knowledge Memory', desc: 'All your meetings build a persistent knowledge base. The AI learns and remembers everything across all sessions.', color: 'bg-gradient-to-br from-purple-600 to-pink-600', delay: 0.7 },
    { icon: <Shield className="w-6 h-6 text-white" />, title: 'Enterprise Security', desc: 'Bank-grade encryption, SOC2 compliant, GDPR ready. Your meeting data stays completely private and secure.', color: 'bg-gradient-to-br from-teal-600 to-cyan-600', delay: 0.8 },
  ];

  const stats = [
    { value: 50000, suffix: '+', label: 'Meetings Analyzed' },
    { value: 98, suffix: '%', label: 'Accuracy Rate' },
    { value: 12, suffix: 'M+', label: 'Action Items Tracked' },
    { value: 5000, suffix: '+', label: 'Teams Using MeetMind' },
  ];

  const fileFormats = [
    { icon: <FileAudio className="w-5 h-5" />, name: 'MP3', color: 'text-violet-400' },
    { icon: <FileVideo className="w-5 h-5" />, name: 'MPEG', color: 'text-blue-400' },
    { icon: <FileVideo className="w-5 h-5" />, name: 'MP4', color: 'text-cyan-400' },
    { icon: <Volume2 className="w-5 h-5" />, name: 'WAV', color: 'text-emerald-400' },
    { icon: <FileAudio className="w-5 h-5" />, name: 'M4A', color: 'text-amber-400' },
    { icon: <FileText className="w-5 h-5" />, name: 'PDF', color: 'text-rose-400' },
    { icon: <FileText className="w-5 h-5" />, name: 'DOC', color: 'text-indigo-400' },
    { icon: <FileText className="w-5 h-5" />, name: 'DOCX', color: 'text-purple-400' },
  ];

  const testimonials = [
    { name: 'Sarah Mitchell', role: 'VP of Product, TechScale', text: 'MeetMind transformed how our team handles meetings. We save 5+ hours weekly and never miss an action item.', rating: 5, avatar: 'SM' },
    { name: 'James Rodriguez', role: 'CEO, GrowthLabs', text: 'The problem-solution analysis is incredible. It surfaces issues we missed and provides concrete next steps automatically.', rating: 5, avatar: 'JR' },
    { name: 'Anika Patel', role: 'Engineering Director, DevCore', text: 'The AI chat feature is a game changer. I can query 6 months of meeting history instantly and get perfect answers.', rating: 5, avatar: 'AP' },
  ];

  const steps = [
    { num: '01', title: 'Upload Any File', desc: 'Drop your audio, video, or document file. We support MP3, MPEG, PDF, DOC and more.', icon: <Upload className="w-6 h-6" /> },
    { num: '02', title: 'AI Analyzes Content', desc: 'Our AI processes the content, identifies speakers, extracts topics, decisions and action items.', icon: <Brain className="w-6 h-6" /> },
    { num: '03', title: 'Get Problems & Solutions', desc: 'Every problem is identified with severity, impact analysis and concrete solution recommendations.', icon: <Target className="w-6 h-6" /> },
    { num: '04', title: 'Chat with Knowledge', desc: 'Use AI chat to ask questions about any meeting, across your entire history, instantly.', icon: <MessageSquare className="w-6 h-6" /> },
  ];

  return (
    <div className="min-h-screen bg-[#050510]">
      {/* Animated Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-violet-600/20 rounded-full blur-[120px]" />
        <div className="absolute top-1/3 -left-40 w-80 h-80 bg-purple-600/15 rounded-full blur-[120px]" />
        <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-blue-600/10 rounded-full blur-[100px]" />
        {Array.from({ length: 50 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-white/20 rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              opacity: [0, 1, 0],
              scale: [0, 1.5, 0],
            }}
            transition={{
              duration: Math.random() * 3 + 2,
              repeat: Infinity,
              delay: Math.random() * 5,
            }}
          />
        ))}
      </div>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center px-4 pt-20">
        <div className="max-w-6xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-violet-500/10 border border-violet-500/30 text-violet-300 text-sm font-medium mb-8"
          >
            <Sparkles className="w-4 h-4" />
            <span>Powered by Advanced AI — Like Tactiq, But More Powerful</span>
            <motion.div
              className="w-2 h-2 bg-emerald-400 rounded-full"
              animate={{ scale: [1, 1.5, 1] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            />
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="text-5xl md:text-7xl lg:text-8xl font-black text-white leading-tight mb-6"
          >
            Transform Meetings
            <br />
            <span className="bg-gradient-to-r from-violet-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              Into Intelligence
            </span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-xl md:text-2xl text-gray-400 max-w-3xl mx-auto leading-relaxed mb-10"
          >
            Upload any meeting file — audio, video, or document. AI instantly extracts
            transcripts, summaries, action items, <span className="text-violet-400 font-semibold">problems with solutions</span>, and builds a
            searchable knowledge base you can chat with.
          </motion.p>

          {/* File Format Badges */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="flex flex-wrap justify-center gap-3 mb-10"
          >
            {fileFormats.map((fmt, i) => (
              <motion.div
                key={fmt.name}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.3 + i * 0.05 }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 ${fmt.color} text-sm font-medium`}
              >
                {fmt.icon}
                {fmt.name}
              </motion.div>
            ))}
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <motion.button
              onClick={() => setCurrentPage('upload')}
              className="flex items-center justify-center gap-2 px-8 py-4 rounded-2xl bg-gradient-to-r from-violet-600 to-purple-600 text-white font-bold text-lg shadow-2xl shadow-purple-500/30 hover:shadow-purple-500/50 transition-shadow"
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.98 }}
            >
              <Upload className="w-5 h-5" />
              Start Analyzing Free
              <ArrowRight className="w-5 h-5" />
            </motion.button>

            <motion.button
              onClick={() => setCurrentPage('dashboard')}
              className="flex items-center justify-center gap-2 px-8 py-4 rounded-2xl bg-white/5 border border-white/15 text-white font-semibold text-lg hover:bg-white/10 transition-all"
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.98 }}
            >
              <PlayCircle className="w-5 h-5 text-violet-400" />
              View Demo
            </motion.button>
          </motion.div>

          {/* Hero Visual */}
          <motion.div
            initial={{ opacity: 0, y: 60, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 1, delay: 0.5 }}
            className="mt-20 relative"
          >
            <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#050510] z-10 pointer-events-none bottom-0 h-1/3" style={{ top: 'auto' }} />
            <div className="relative bg-white/[0.03] border border-white/10 rounded-3xl overflow-hidden shadow-2xl">
              {/* Fake App Preview */}
              <div className="bg-[#0a0a1a] px-4 py-3 border-b border-white/5 flex items-center gap-2">
                <div className="flex gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-500/60" />
                  <div className="w-3 h-3 rounded-full bg-yellow-500/60" />
                  <div className="w-3 h-3 rounded-full bg-green-500/60" />
                </div>
                <div className="flex-1 mx-4 bg-white/5 rounded-lg h-6 flex items-center px-3">
                  <span className="text-gray-500 text-xs">meetmind.ai/analysis/q4-roadmap-2024</span>
                </div>
              </div>
              <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Transcript panel */}
                <div className="md:col-span-2 space-y-3">
                  <div className="flex items-center gap-2 mb-4">
                    <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
                    <span className="text-emerald-400 text-sm font-medium">AI Analysis Complete</span>
                  </div>
                  {[
                    { label: '📋 Summary', text: 'Q4 roadmap meeting identified critical API performance issues (2.3s avg) and mobile crash rate problems...', color: 'violet' },
                    { label: '⚠️ Problem #1', text: 'API response time 40% above benchmark — impacting enterprise client satisfaction', color: 'rose' },
                    { label: '✅ Solution #1', text: 'Implement Redis caching layer — David Park assigned, 5-day timeline, high feasibility', color: 'emerald' },
                    { label: '📌 Action Item', text: 'Redis caching implementation due Dec 8 — David Park | Priority: HIGH', color: 'amber' },
                  ].map((item, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.8 + i * 0.15 }}
                      className={`p-3 rounded-xl bg-${item.color}-500/5 border border-${item.color}-500/20`}
                    >
                      <div className={`text-${item.color}-400 text-xs font-semibold mb-1`}>{item.label}</div>
                      <div className="text-gray-300 text-sm">{item.text}</div>
                    </motion.div>
                  ))}
                </div>
                {/* Stats panel */}
                <div className="space-y-3">
                  <div className="p-4 rounded-xl bg-violet-500/10 border border-violet-500/20">
                    <div className="text-3xl font-black text-violet-400 mb-1">72</div>
                    <div className="text-gray-400 text-sm">Meeting Score</div>
                    <div className="mt-2 h-1.5 bg-white/10 rounded-full overflow-hidden">
                      <motion.div
                        className="h-full bg-gradient-to-r from-violet-500 to-purple-500 rounded-full"
                        initial={{ width: 0 }}
                        animate={{ width: '72%' }}
                        transition={{ delay: 1, duration: 1 }}
                      />
                    </div>
                  </div>
                  {[
                    { label: 'Problems Found', value: '4', color: 'rose' },
                    { label: 'Solutions', value: '4', color: 'emerald' },
                    { label: 'Action Items', value: '5', color: 'amber' },
                    { label: 'Decisions', value: '3', color: 'blue' },
                  ].map((stat, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 1 + i * 0.1 }}
                      className={`p-3 rounded-xl bg-${stat.color}-500/10 border border-${stat.color}-500/20 flex items-center justify-between`}
                    >
                      <span className="text-gray-400 text-sm">{stat.label}</span>
                      <span className={`text-${stat.color}-400 font-bold text-lg`}>{stat.value}</span>
                    </motion.div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="relative py-20 px-4">
        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="text-center"
              >
                <div className="text-4xl md:text-5xl font-black text-white mb-2">
                  <AnimatedCounter end={stat.value} suffix={stat.suffix} />
                </div>
                <div className="text-gray-400 text-sm">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="relative py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-300 text-sm font-medium mb-4">
              <Zap className="w-4 h-4" />
              How It Works
            </div>
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4">
              4 Steps to Meeting Intelligence
            </h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">
              From raw file to actionable intelligence in minutes
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {steps.map((step, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.15 }}
                className="relative"
              >
                {i < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-10 left-full w-full h-px bg-gradient-to-r from-violet-500/50 to-transparent z-0" />
                )}
                <div className="relative bg-white/[0.03] border border-white/10 rounded-2xl p-6 hover:border-violet-500/30 transition-all group">
                  <div className="text-6xl font-black text-white/5 absolute top-4 right-4">{step.num}</div>
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-violet-600 to-purple-600 flex items-center justify-center mb-4 text-white shadow-lg shadow-violet-500/20">
                    {step.icon}
                  </div>
                  <h3 className="text-white font-bold text-lg mb-2">{step.title}</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">{step.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="relative py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-violet-500/10 border border-violet-500/30 text-violet-300 text-sm font-medium mb-4">
              <Sparkles className="w-4 h-4" />
              Full Feature Suite
            </div>
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4">
              Everything You Need
            </h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">
              A complete meeting intelligence platform, more powerful than any alternative
            </p>
          </motion.div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {features.map((f, i) => (
              <FeatureCard key={i} {...f} />
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="relative py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4">
              Loved by 5,000+ Teams
            </h2>
          </motion.div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((t, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.15 }}
                whileHover={{ y: -5 }}
                className="bg-white/[0.03] border border-white/10 rounded-2xl p-6"
              >
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: t.rating }).map((_, j) => (
                    <Star key={j} className="w-4 h-4 text-amber-400 fill-amber-400" />
                  ))}
                </div>
                <p className="text-gray-300 text-sm leading-relaxed mb-6">"{t.text}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-violet-600 to-purple-600 flex items-center justify-center text-white font-bold text-sm">
                    {t.avatar}
                  </div>
                  <div>
                    <div className="text-white font-semibold text-sm">{t.name}</div>
                    <div className="text-gray-500 text-xs">{t.role}</div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative py-24 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative bg-gradient-to-br from-violet-600/20 to-purple-600/10 border border-violet-500/30 rounded-3xl p-12 overflow-hidden"
          >
            <div className="absolute inset-0 overflow-hidden">
              <div className="absolute -top-20 -right-20 w-64 h-64 bg-violet-600/20 rounded-full blur-[80px]" />
              <div className="absolute -bottom-20 -left-20 w-64 h-64 bg-purple-600/20 rounded-full blur-[80px]" />
            </div>
            <div className="relative">
              <motion.div
                animate={{ rotate: [0, 360] }}
                transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
                className="w-16 h-16 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-violet-600 to-purple-600 flex items-center justify-center shadow-2xl shadow-purple-500/40"
              >
                <Brain className="w-9 h-9 text-white" />
              </motion.div>
              <h2 className="text-4xl md:text-5xl font-black text-white mb-4">
                Ready to Transform Your Meetings?
              </h2>
              <p className="text-gray-300 text-lg mb-8 max-w-2xl mx-auto">
                Join thousands of teams who save hours every week with MeetMind AI.
                Start analyzing your meetings for free today.
              </p>
              <motion.button
                onClick={() => setCurrentPage('upload')}
                className="inline-flex items-center gap-2 px-10 py-4 rounded-2xl bg-gradient-to-r from-violet-600 to-purple-600 text-white font-bold text-lg shadow-2xl shadow-purple-500/30"
                whileHover={{ scale: 1.05, y: -2 }}
                whileTap={{ scale: 0.98 }}
              >
                <Upload className="w-5 h-5" />
                Analyze Your First Meeting Free
                <ChevronRight className="w-5 h-5" />
              </motion.button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
