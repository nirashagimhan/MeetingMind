import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Send, Brain, User, Sparkles, RefreshCw, Lightbulb,
  AlertCircle, CheckCircle, FileText, Copy, ThumbsUp, MessageSquare
} from 'lucide-react';
import { ChatMessage, Meeting } from '../types';
import { AI_KNOWLEDGE_BASE, KNOWLEDGE_BASE_FACTS } from '../data/mockDatabase';

interface ChatPageProps {
  meetings: Meeting[];
}

const generateAIResponse = (userMessage: string, meetings: Meeting[]): string => {
  const msg = userMessage.toLowerCase();

  // Check knowledge base
  for (const [key, answers] of Object.entries(AI_KNOWLEDGE_BASE)) {
    if (msg.includes(key.split(' ')[0]) || key.split(' ').some(word => msg.includes(word))) {
      const randomAnswer = answers[Math.floor(Math.random() * answers.length)];
      return `Based on your meeting knowledge base:\n\n${randomAnswer}\n\n${answers.length > 1 ? `\nI also know that: ${answers[1]}` : ''}\n\n*Want me to go deeper on any aspect of this?*`;
    }
  }

  // Meeting-specific queries
  if (msg.includes('how many meeting') || msg.includes('total meeting')) {
    return `You have **${meetings.length} meetings** in your knowledge base:\n\n${meetings.map((m, i) => `${i + 1}. **${m.title}** (${m.date}) — ${m.duration}, ${m.participants.length} participants`).join('\n')}\n\nWould you like details about any specific meeting?`;
  }

  if (msg.includes('action item') || msg.includes('task') || msg.includes('todo')) {
    const allActions = meetings.flatMap(m => m.summary?.actionItems || []);
    const pending = allActions.filter(a => a.status === 'pending');
    return `You have **${allActions.length} total action items** across all meetings:\n\n🔴 **Pending:** ${pending.length}\n🟡 **In Progress:** ${allActions.filter(a => a.status === 'in-progress').length}\n🟢 **Completed:** ${allActions.filter(a => a.status === 'completed').length}\n\n**Most urgent pending items:**\n${pending.slice(0, 3).map(a => `• ${a.task} — *${a.assignee}* (${a.deadline})`).join('\n')}\n\n*Ask me about specific assignees or deadlines for more detail.*`;
  }

  if (msg.includes('problem') || msg.includes('issue') || msg.includes('challenge')) {
    const allProblems = meetings.flatMap(m => m.summary?.problems || []);
    const critical = allProblems.filter(p => p.severity === 'critical');
    return `Across all your meetings, I've identified **${allProblems.length} problems**:\n\n🔴 **Critical:** ${critical.length} — ${critical.map(p => p.title).join(', ')}\n🟠 **High:** ${allProblems.filter(p => p.severity === 'high').length}\n🟡 **Medium:** ${allProblems.filter(p => p.severity === 'medium').length}\n\n**Top critical problem:** ${critical[0]?.title || 'None'}\n${critical[0]?.description || ''}\n\n**Recommended solution:** ${meetings.flatMap(m => m.summary?.solutions || []).find(s => s.problemId === critical[0]?.id)?.title || 'Review analysis for solutions'}\n\n*Want me to detail solutions for any specific problem?*`;
  }

  if (msg.includes('solution') || msg.includes('fix') || msg.includes('resolve')) {
    const allSolutions = meetings.flatMap(m => m.summary?.solutions || []);
    return `I have **${allSolutions.length} solutions** documented across your meetings:\n\n${allSolutions.slice(0, 4).map(s => `✅ **${s.title}**\n   → ${s.description}\n   → Owner: ${s.owner} | Timeline: ${s.timeframe} | Feasibility: ${s.feasibility.toUpperCase()}`).join('\n\n')}\n\n*Ask about a specific problem's solution for detailed implementation steps.*`;
  }

  if (msg.includes('decision') || msg.includes('decided') || msg.includes('approved')) {
    const allDecisions = meetings.flatMap(m => m.summary?.decisions || []);
    return `**${allDecisions.length} key decisions** made across your meetings:\n\n${allDecisions.map(d => `🏴 **${d.decision}**\n   Made by: ${d.madeBy} | Impact: ${d.impact.toUpperCase()}\n   Rationale: ${d.rationale}`).join('\n\n')}\n\n*Need more context on any decision?*`;
  }

  if (msg.includes('participant') || msg.includes('who') || msg.includes('attendee')) {
    const allParticipants = [...new Set(meetings.flatMap(m => m.participants))];
    return `**${allParticipants.length} unique participants** across all meetings:\n\n${allParticipants.slice(0, 8).map(p => `• ${p}`).join('\n')}\n\n*Ask about a specific person's action items or contributions.*`;
  }

  if (msg.includes('summary') || msg.includes('overview') || msg.includes('what happened')) {
    const latestMeeting = meetings[0];
    if (!latestMeeting?.summary) return "No meetings analyzed yet. Please upload a meeting file first.";
    return `**Latest Meeting Summary: ${latestMeeting.title}**\n\nDate: ${latestMeeting.date} | Duration: ${latestMeeting.duration}\n\n📋 ${latestMeeting.summary.overview}\n\n**Key Points:**\n${latestMeeting.summary.keyPoints.slice(0, 4).map(kp => `• ${kp}`).join('\n')}\n\n**Score:** ${latestMeeting.summary.meetingScore}/100 | **Sentiment:** ${latestMeeting.summary.sentiment}`;
  }

  if (msg.includes('risk') || msg.includes('concern') || msg.includes('danger')) {
    const allRisks = meetings.flatMap(m => m.summary?.riskAssessment || []);
    return `**${allRisks.length} risks identified** across your meetings:\n\n${allRisks.map(r => `⚠️ **${r.title}**\n   Probability: ${r.probability.toUpperCase()} | Impact: ${r.impact.toUpperCase()}\n   Mitigation: ${r.mitigation}\n   Owner: ${r.owner}`).join('\n\n')}\n\n*Need mitigation strategies for any specific risk?*`;
  }

  if (msg.includes('hire') || msg.includes('engineer') || msg.includes('team') || msg.includes('staff')) {
    return `From the Q4 Product Roadmap meeting:\n\n👥 **Hiring Decision:** 2 senior engineers approved for immediate hire\n\n**Reason:** Team bandwidth insufficient for Q4 workload at required quality standards\n**Timeline:** Job postings were to go live December 2, 2024\n**Assigned to:** Sarah Chen (HR coordination)\n\nThis was classified as a **HIGH impact** decision. The 30% annual engineering turnover was also flagged as a risk requiring the mentorship program initiative.\n\n*Want more details about the hiring justification or team structure?*`;
  }

  if (msg.includes('redis') || msg.includes('cache') || msg.includes('api') || msg.includes('performance')) {
    return `From your Q4 Product Roadmap meeting:\n\n🔴 **Problem:** API response times averaging 2.3 seconds (40% above the 1.4s benchmark)\n\n💡 **Solution: Redis Caching Implementation**\n• Owner: David Park\n• Timeline: 5 days\n• Expected improvement: 60-70% reduction in response time\n• Status: P0 (Critical Priority)\n\n**Implementation Steps:**\n1. Set up Redis server\n2. Identify cacheable API endpoints\n3. Implement cache invalidation strategy\n4. Test with load simulation\n5. Monitor cache hit rate\n\n*This was the top priority item from the Q4 planning session.*`;
  }

  if (msg.includes('europe') || msg.includes('european') || msg.includes('emea') || msg.includes('expansion')) {
    return `From your 2025 Strategy Review meeting:\n\n🌍 **European Expansion Plan:**\n• Budget Approved: **$2M**\n• Market Opportunity: **$12M TAM**\n• Go-to-Market Lead: Amanda Foster\n• Target Date: Q2 2025\n\n⚠️ **Key Challenge:** EMEA brand awareness currently only 12% of target market\n\n**Solution:** $500K EMEA brand campaign\n• Hire EMEA marketing manager\n• Sponsor 3 major EU tech conferences\n• Launch localized content strategy\n• Partner with EU analyst firms\n\n⚖️ **Risk:** European regulatory compliance (GDPR, data residency)\nMitigation: Engage EU legal counsel, GDPR compliance audit\n\n*Need the full go-to-market timeline?*`;
  }

  if (msg.includes('hello') || msg.includes('hi') || msg.includes('hey') || msg.includes('start')) {
    const totalMeetings = meetings.length;
    const totalProblems = meetings.flatMap(m => m.summary?.problems || []).length;
    const totalActions = meetings.flatMap(m => m.summary?.actionItems || []).length;
    return `👋 **Hello! I'm MeetMind AI** — your intelligent meeting assistant.\n\nI have complete knowledge of all your analyzed meetings:\n\n📊 **Your Knowledge Base:**\n• ${totalMeetings} meetings analyzed\n• ${totalProblems} problems identified\n• ${totalActions} action items tracked\n• Multiple topics and decisions documented\n\n💬 **You can ask me about:**\n• Specific problems and their solutions\n• Action items and who's responsible\n• Key decisions made\n• Participant contributions\n• Risks and mitigation strategies\n• Any meeting topic or keyword\n\n*What would you like to know?*`;
  }

  if (msg.includes('churn') || msg.includes('customer') || msg.includes('retention')) {
    return `From the 2025 Strategy Review:\n\n📉 **Customer Churn Problem:**\n• Current churn: **8%** (industry average is 5%)\n• Trend: Increasing over last 2 quarters\n• Financial Impact: **$400K ARR lost quarterly**\n\n💡 **Solution: Customer Success Program Overhaul**\n• Implement health score model for proactive intervention\n• Create playbooks for at-risk accounts\n• Add dedicated CSM for enterprise tier\n• Introduce quarterly business reviews (QBRs)\n• Launch NPS improvement program\n• Timeline: 3 months | Owner: Jennifer Walsh\n• Budget: ~$50K (CRM upgrade included)\n\n*Want details on the health scoring methodology or the specific playbook structure?*`;
  }

  if (msg.includes('score') || msg.includes('quality') || msg.includes('rating')) {
    const scores = meetings.filter(m => m.summary).map(m => ({ title: m.title, score: m.summary!.meetingScore }));
    return `**Meeting Quality Scores:**\n\n${scores.map(s => `${s.score >= 80 ? '🟢' : s.score >= 60 ? '🟡' : '🔴'} **${s.title}:** ${s.score}/100`).join('\n')}\n\n**Average Score:** ${scores.length ? Math.round(scores.reduce((a, b) => a + b.score, 0) / scores.length) : 0}/100\n\nScoring considers: action item clarity, decision quality, problem identification, participation balance, and outcome clarity.\n\n*Higher scoring meetings have clearer outcomes and better structured follow-ups.*`;
  }

  // Default intelligent response
  const topics = Object.keys(AI_KNOWLEDGE_BASE);
  const suggestions = topics.slice(0, 4).map(t => `• "${t.charAt(0).toUpperCase() + t.slice(1)}"`);
  return `I have comprehensive knowledge of all your analyzed meetings. I couldn't find specific information about "${userMessage}" in the current context.\n\n**Try asking me about:**\n${suggestions.join('\n')}\n• Specific participants and their tasks\n• Problems and solutions from any meeting\n• Decisions made and their rationale\n• Upcoming deadlines and priorities\n\nOr try rephrasing — I understand natural language questions about your meetings! 💡`;
};

const ChatPage: React.FC<ChatPageProps> = ({ meetings }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      role: 'assistant',
      content: `👋 **Welcome to MeetMind AI Chat!**\n\nI have deep knowledge of all your analyzed meetings. I can answer questions about:\n\n• 🔍 **Problems & Solutions** identified in meetings\n• ✅ **Action items** and who's responsible\n• 🏴 **Key decisions** and their rationale\n• 📊 **Analytics** and participation data\n• ⚠️ **Risks** and mitigation strategies\n• 👥 **Team** contributions and sentiment\n\n*Ask me anything about your meetings!*`,
      timestamp: new Date(),
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;
    const userMsg = input.trim();
    setInput('');

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: userMsg,
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, userMessage]);
    setIsTyping(true);

    await new Promise(r => setTimeout(r, 800 + Math.random() * 1200));

    const response = generateAIResponse(userMsg, meetings);
    const aiMessage: ChatMessage = {
      id: (Date.now() + 1).toString(),
      role: 'assistant',
      content: response,
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, aiMessage]);
    setIsTyping(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const copyMessage = (id: string, content: string) => {
    navigator.clipboard.writeText(content);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const formatMessage = (content: string) => {
    return content
      .replace(/\*\*(.*?)\*\*/g, '<strong class="text-white font-semibold">$1</strong>')
      .replace(/\*(.*?)\*/g, '<em class="text-gray-400">$1</em>')
      .replace(/\n/g, '<br />');
  };

  const suggestions = [
    'What problems were identified in meetings?',
    'Show me all action items and who owns them',
    'What decisions were made in the strategy review?',
    'What is the status of the European expansion?',
    'Tell me about API performance issues and solutions',
    'What are the current risks across all meetings?',
  ];

  return (
    <div className="min-h-screen bg-[#050510] pt-20 flex flex-col">
      <div className="max-w-4xl mx-auto w-full flex-1 flex flex-col px-4 pb-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="py-6 flex items-center justify-between"
        >
          <div>
            <h1 className="text-2xl font-black text-white flex items-center gap-2">
              <Brain className="w-7 h-7 text-violet-400" />
              AI Meeting Assistant
            </h1>
            <p className="text-gray-400 text-sm mt-1">
              {meetings.length} meetings in knowledge base • Ask me anything
            </p>
          </div>
          <div className="flex items-center gap-2">
            <motion.div
              className="w-2 h-2 bg-emerald-400 rounded-full"
              animate={{ scale: [1, 1.3, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
            />
            <span className="text-emerald-400 text-sm font-medium">Online</span>
          </div>
        </motion.div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto space-y-4 mb-4 min-h-0" style={{ maxHeight: 'calc(100vh - 280px)' }}>
          <AnimatePresence initial={false}>
            {messages.map((message) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 20, scale: 0.96 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, scale: 0.96 }}
                transition={{ duration: 0.3 }}
                className={`flex gap-3 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {message.role === 'assistant' && (
                  <motion.div
                    className="w-9 h-9 rounded-xl bg-gradient-to-br from-violet-600 to-purple-600 flex items-center justify-center flex-shrink-0 shadow-lg shadow-violet-500/20"
                    animate={{ rotate: [0, 5, -5, 0] }}
                    transition={{ duration: 4, repeat: Infinity }}
                  >
                    <Brain className="w-5 h-5 text-white" />
                  </motion.div>
                )}
                <div className={`max-w-[80%] group`}>
                  <div
                    className={`px-4 py-3 rounded-2xl text-sm leading-relaxed ${
                      message.role === 'user'
                        ? 'bg-gradient-to-r from-violet-600 to-purple-600 text-white rounded-tr-sm shadow-lg shadow-violet-500/20'
                        : 'bg-white/[0.05] border border-white/10 text-gray-200 rounded-tl-sm'
                    }`}
                  >
                    <div
                      dangerouslySetInnerHTML={{ __html: formatMessage(message.content) }}
                    />
                  </div>
                  {message.role === 'assistant' && (
                    <div className="flex items-center gap-2 mt-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => copyMessage(message.id, message.content)}
                        className="text-gray-500 hover:text-gray-300 transition-colors p-1"
                      >
                        {copiedId === message.id ? (
                          <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                      <button className="text-gray-500 hover:text-violet-400 transition-colors p-1">
                        <ThumbsUp className="w-3.5 h-3.5" />
                      </button>
                      <span className="text-gray-600 text-xs">
                        {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  )}
                </div>
                {message.role === 'user' && (
                  <div className="w-9 h-9 rounded-xl bg-white/10 border border-white/10 flex items-center justify-center flex-shrink-0">
                    <User className="w-5 h-5 text-gray-300" />
                  </div>
                )}
              </motion.div>
            ))}

            {/* Typing Indicator */}
            {isTyping && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="flex gap-3 items-start"
              >
                <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-violet-600 to-purple-600 flex items-center justify-center flex-shrink-0">
                  <Brain className="w-5 h-5 text-white" />
                </div>
                <div className="px-4 py-3 rounded-2xl bg-white/[0.05] border border-white/10 rounded-tl-sm">
                  <div className="flex gap-1.5 items-center">
                    {[0, 1, 2].map(i => (
                      <motion.div
                        key={i}
                        className="w-2 h-2 bg-violet-400 rounded-full"
                        animate={{ y: [0, -6, 0] }}
                        transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.2 }}
                      />
                    ))}
                    <span className="text-gray-500 text-xs ml-2">AI is thinking...</span>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
          <div ref={messagesEndRef} />
        </div>

        {/* Suggestions */}
        {messages.length <= 2 && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-4"
          >
            <div className="text-gray-500 text-xs mb-2 flex items-center gap-1">
              <Lightbulb className="w-3 h-3" /> Suggested questions:
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {suggestions.slice(0, 4).map((s, i) => (
                <motion.button
                  key={i}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.05 }}
                  onClick={() => { setInput(s); inputRef.current?.focus(); }}
                  className="text-left text-xs px-3 py-2.5 rounded-xl bg-white/[0.03] border border-white/10 text-gray-400 hover:text-violet-300 hover:border-violet-500/30 transition-all"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  💬 {s}
                </motion.button>
              ))}
            </div>
          </motion.div>
        )}

        {/* Input */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative"
        >
          <div className="flex gap-3 items-end bg-white/[0.03] border border-white/15 rounded-2xl p-3 focus-within:border-violet-500/50 transition-colors">
            <textarea
              ref={inputRef}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask me anything about your meetings..."
              rows={1}
              className="flex-1 bg-transparent text-white placeholder-gray-500 text-sm resize-none outline-none leading-relaxed min-h-[24px] max-h-[120px]"
              style={{ height: 'auto' }}
              onInput={e => {
                const el = e.target as HTMLTextAreaElement;
                el.style.height = 'auto';
                el.style.height = Math.min(el.scrollHeight, 120) + 'px';
              }}
            />
            <motion.button
              onClick={handleSend}
              disabled={!input.trim() || isTyping}
              className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 transition-all ${
                input.trim() && !isTyping
                  ? 'bg-gradient-to-r from-violet-600 to-purple-600 text-white shadow-lg shadow-violet-500/20 hover:shadow-violet-500/40'
                  : 'bg-white/5 text-gray-600 cursor-not-allowed'
              }`}
              whileHover={input.trim() && !isTyping ? { scale: 1.1 } : {}}
              whileTap={input.trim() && !isTyping ? { scale: 0.9 } : {}}
            >
              <Send className="w-4 h-4" />
            </motion.button>
          </div>
          <p className="text-gray-600 text-xs mt-2 text-center">
            Press Enter to send • Shift+Enter for new line • I know everything about your meetings
          </p>
        </motion.div>
      </div>
    </div>
  );
};

export default ChatPage;
