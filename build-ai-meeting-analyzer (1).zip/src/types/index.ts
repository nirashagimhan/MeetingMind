export interface Meeting {
  id: string;
  title: string;
  date: string;
  duration: string;
  participants: string[];
  fileType: string;
  fileName: string;
  status: 'processing' | 'completed' | 'error';
  transcript?: string;
  summary?: MeetingSummary;
  tags?: string[];
  fileSize?: string;
}

export interface MeetingSummary {
  overview: string;
  keyPoints: string[];
  actionItems: ActionItem[];
  decisions: Decision[];
  problems: Problem[];
  solutions: Solution[];
  nextSteps: string[];
  sentiment: 'positive' | 'neutral' | 'negative' | 'mixed';
  topics: Topic[];
  participants: ParticipantAnalysis[];
  wordCloud: WordItem[];
  timeline: TimelineItem[];
  riskAssessment: Risk[];
  meetingScore: number;
}

export interface ActionItem {
  id: string;
  task: string;
  assignee: string;
  deadline: string;
  priority: 'high' | 'medium' | 'low';
  status: 'pending' | 'in-progress' | 'completed';
  category: string;
}

export interface Decision {
  id: string;
  decision: string;
  madeBy: string;
  impact: 'high' | 'medium' | 'low';
  rationale: string;
  timestamp?: string;
}

export interface Problem {
  id: string;
  title: string;
  description: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  category: string;
  identifiedBy: string;
  context: string;
  impact: string;
}

export interface Solution {
  id: string;
  problemId: string;
  title: string;
  description: string;
  feasibility: 'high' | 'medium' | 'low';
  timeframe: string;
  resources: string;
  owner: string;
  steps: string[];
}

export interface Topic {
  name: string;
  duration: number;
  percentage: number;
  color: string;
}

export interface ParticipantAnalysis {
  name: string;
  speakingTime: number;
  contributions: number;
  actionItems: number;
  sentiment: 'positive' | 'neutral' | 'negative';
  avatar: string;
  role: string;
}

export interface WordItem {
  text: string;
  value: number;
  color: string;
}

export interface TimelineItem {
  time: string;
  event: string;
  type: 'decision' | 'action' | 'discussion' | 'concern' | 'milestone';
  speaker?: string;
}

export interface Risk {
  id: string;
  title: string;
  probability: 'high' | 'medium' | 'low';
  impact: 'high' | 'medium' | 'low';
  mitigation: string;
  owner: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  meetingRef?: string;
  sources?: string[];
  isTyping?: boolean;
}

export interface KnowledgeBase {
  meetings: Meeting[];
  totalTopics: string[];
  participants: string[];
  decisions: Decision[];
  actionItems: ActionItem[];
  problems: Problem[];
  solutions: Solution[];
}
