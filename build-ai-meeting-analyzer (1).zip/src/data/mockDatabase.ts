import { Meeting, KnowledgeBase } from '../types';

export const KNOWLEDGE_BASE_FACTS = {
  productDevelopment: {
    meetings: [
      "Q4 2024 Sprint Planning discussed mobile app feature delays",
      "Team agreed to postpone social sharing to Q1 2025",
      "Backend API performance issues identified - 40% slower than benchmarks",
      "UI redesign approved for dashboard module",
      "User testing revealed 3 critical UX issues",
    ],
    decisions: [
      "Adopt microservices architecture by March 2025",
      "Use React Native for mobile development",
      "Implement Redis caching for API responses",
      "Hire 2 senior engineers for scaling team",
    ],
    problems: [
      "API response time exceeding 2 seconds",
      "Mobile app crash rate at 2.3% (target < 0.5%)",
      "Database queries not optimized for large datasets",
      "Cross-browser compatibility issues in Safari",
    ]
  },
  businessStrategy: {
    meetings: [
      "Annual strategy review identified 3 new market opportunities",
      "Competitor analysis shows 20% market share gap",
      "European expansion budget approved at $2M",
      "Partnership with TechCorp discussed and approved",
      "Pricing model revision needed for enterprise tier",
    ],
    decisions: [
      "Expand to European market by Q2 2025",
      "Launch enterprise tier at $999/month",
      "Acquire AI startup for $5M to accelerate roadmap",
      "Rebrand product line by Q3 2025",
    ],
    problems: [
      "Customer churn rate at 8% (industry average 5%)",
      "Sales pipeline conversion dropping 15%",
      "Brand awareness low in EMEA region",
      "Enterprise customers need custom SLA",
    ]
  },
  teamManagement: {
    meetings: [
      "Performance reviews completed for Q3 2024",
      "Remote work policy updated to 3 days WFH",
      "Engineering hiring plan approved - 12 positions",
      "DEI initiatives launched with 3 new programs",
      "Team satisfaction survey showed 78% positive",
    ],
    decisions: [
      "Implement OKR framework company-wide",
      "Increase team budget by 25% for L&D",
      "Introduce bi-weekly all-hands meetings",
      "Create mentorship program for junior staff",
    ],
    problems: [
      "High turnover in engineering (30% annually)",
      "Remote collaboration challenges with APAC team",
      "Knowledge silos between departments",
      "Junior engineers lack mentorship",
    ]
  },
  financials: {
    meetings: [
      "Q3 2024 revenue at $4.2M (10% above target)",
      "OpEx review identified $300K in savings",
      "Series B fundraising round opened at $15M target",
      "Customer acquisition cost increased 20%",
      "Gross margin improved to 68%",
    ],
    decisions: [
      "Reduce marketing spend by 15% and shift to content",
      "Extend runway to 18 months before next fundraise",
      "Automate billing system to save 40 hours/month",
      "Negotiate better vendor contracts for cloud hosting",
    ],
    problems: [
      "CAC increased from $120 to $145 per customer",
      "Payment processing failures at 0.8%",
      "Forecast accuracy only 72% (target 90%)",
      "Burn rate 10% above projections",
    ]
  }
};

export const SAMPLE_MEETINGS: Meeting[] = [
  {
    id: '1',
    title: 'Q4 Product Roadmap Planning',
    date: '2024-12-15',
    duration: '1h 42m',
    participants: ['Sarah Chen', 'Marcus Johnson', 'Elena Rodriguez', 'David Park', 'Lisa Wang'],
    fileType: 'audio/mpeg',
    fileName: 'q4_product_roadmap.mp3',
    status: 'completed',
    fileSize: '42.3 MB',
    tags: ['Product', 'Strategy', 'Q4'],
    transcript: `Sarah Chen: Good morning everyone. Let's start with our Q4 roadmap review. 
    Marcus, can you give us the status update?
    
    Marcus Johnson: Sure. We're running about 2 weeks behind on the mobile feature set. 
    The API integration is proving more complex than estimated. We identified performance 
    issues - response times are averaging 2.3 seconds, which is 40% above our benchmark.
    
    Elena Rodriguez: That's concerning. Our enterprise clients expect sub-second responses.
    What's causing the bottleneck?
    
    Marcus Johnson: We traced it to unoptimized database queries and lack of caching. 
    We need to implement Redis caching immediately.
    
    David Park: I can have that ready in the next sprint. Should fix 60-70% of the issue.
    
    Sarah Chen: Good. Let's make that a P0 item. What about the UI redesign?
    
    Lisa Wang: UI mockups are approved. We start implementation next Monday. 
    But we found 3 critical UX issues in user testing - navigation is confusing, 
    loading states are unclear, and the mobile experience needs complete rework.
    
    Sarah Chen: We need to address those before the December launch. 
    Let's postpone social sharing features to Q1 2025 and focus on core quality.
    
    Marcus Johnson: Agreed. Also, we should discuss the mobile app crash rate - 
    it's at 2.3% which is way above our 0.5% target.
    
    David Park: I'll prioritize crash fix releases. We need at least 2 more senior engineers 
    to handle the workload properly.
    
    Sarah Chen: Approved. HR will open 2 senior engineer positions this week.
    
    Elena Rodriguez: One more thing - Safari compatibility. We're breaking on Safari 16.
    
    Marcus Johnson: Known issue. Fix is in next sprint.
    
    Sarah Chen: Perfect. Let's wrap up. Action items: Redis caching by EOD Friday, 
    UX fixes by Dec 10, crash rate below 1% by Dec 15, job postings live by Monday.`,
    summary: {
      overview: "Q4 product roadmap planning meeting focused on addressing critical technical issues including API performance (2.3s avg response time vs 1.4s benchmark), mobile app crashes (2.3% vs 0.5% target), and UI/UX improvements before December launch. Team made key decisions on resource allocation and feature prioritization.",
      keyPoints: [
        "Mobile feature set is 2 weeks behind schedule",
        "API response times averaging 2.3 seconds (40% above benchmark)",
        "Mobile app crash rate at 2.3% (target is 0.5%)",
        "3 critical UX issues identified in user testing",
        "Social sharing features postponed to Q1 2025",
        "2 senior engineer positions approved for immediate hiring"
      ],
      actionItems: [
        { id: 'a1', task: 'Implement Redis caching for API optimization', assignee: 'David Park', deadline: 'Dec 8, 2024', priority: 'high', status: 'pending', category: 'Technical' },
        { id: 'a2', task: 'Fix 3 critical UX issues from user testing', assignee: 'Lisa Wang', deadline: 'Dec 10, 2024', priority: 'high', status: 'in-progress', category: 'Design' },
        { id: 'a3', task: 'Reduce crash rate below 1%', assignee: 'Marcus Johnson', deadline: 'Dec 15, 2024', priority: 'high', status: 'pending', category: 'Engineering' },
        { id: 'a4', task: 'Post 2 senior engineer job openings', assignee: 'Sarah Chen', deadline: 'Dec 2, 2024', priority: 'medium', status: 'completed', category: 'HR' },
        { id: 'a5', task: 'Fix Safari 16 compatibility issue', assignee: 'Marcus Johnson', deadline: 'Dec 12, 2024', priority: 'medium', status: 'pending', category: 'Engineering' }
      ],
      decisions: [
        { id: 'd1', decision: 'Postpone social sharing features to Q1 2025', madeBy: 'Sarah Chen', impact: 'medium', rationale: 'Focus on core quality and fix critical issues before launch', timestamp: '10:23 AM' },
        { id: 'd2', decision: 'Hire 2 additional senior engineers immediately', madeBy: 'Sarah Chen', impact: 'high', rationale: 'Current team lacks bandwidth to handle workload at required quality', timestamp: '10:45 AM' },
        { id: 'd3', decision: 'Implement Redis caching as P0 priority', madeBy: 'Team', impact: 'high', rationale: 'API performance 40% below benchmark affecting enterprise client satisfaction', timestamp: '10:15 AM' }
      ],
      problems: [
        { id: 'p1', title: 'API Performance Below Benchmark', description: 'API response times averaging 2.3 seconds, 40% above the 1.4 second benchmark', severity: 'critical', category: 'Performance', identifiedBy: 'Marcus Johnson', context: 'Enterprise clients require sub-second API responses for their integrations', impact: 'Enterprise client satisfaction at risk, potential churn of $200K ARR accounts' },
        { id: 'p2', title: 'Mobile App Crash Rate Critical', description: 'Current crash rate at 2.3%, far exceeding the 0.5% target', severity: 'critical', category: 'Reliability', identifiedBy: 'Marcus Johnson', context: 'Mobile app is primary product for 60% of user base', impact: 'User experience severely degraded, negative app store reviews increasing' },
        { id: 'p3', title: 'UX Issues Found in Testing', description: '3 critical UX problems: confusing navigation, unclear loading states, poor mobile experience', severity: 'high', category: 'User Experience', identifiedBy: 'Lisa Wang', context: 'User testing conducted with 20 participants before Q4 launch', impact: 'Launch readiness at risk, potential high churn post-launch if not addressed' },
        { id: 'p4', title: 'Safari Browser Compatibility', description: 'Application breaking on Safari 16 affecting significant portion of users', severity: 'high', category: 'Compatibility', identifiedBy: 'Elena Rodriguez', context: 'Safari is used by ~30% of enterprise clients on Mac devices', impact: 'Enterprise clients unable to use product on Mac systems' }
      ],
      solutions: [
        { id: 's1', problemId: 'p1', title: 'Implement Redis Caching Layer', description: 'Add Redis caching to API responses to reduce database load and improve response times', feasibility: 'high', timeframe: '5 days', resources: '1 senior engineer, Redis license', owner: 'David Park', steps: ['Set up Redis server', 'Identify cacheable endpoints', 'Implement cache invalidation strategy', 'Test with load simulation', 'Monitor and optimize cache hit rate'] },
        { id: 's2', problemId: 'p2', title: 'Crash Detection & Fix Sprint', description: 'Dedicated 2-week sprint to identify and fix all crash sources using crash analytics', feasibility: 'high', timeframe: '2 weeks', resources: '2 engineers, Crashlytics premium', owner: 'Marcus Johnson', steps: ['Analyze crash reports in Crashlytics', 'Prioritize by frequency', 'Fix top 5 crash causes', 'Release hotfix builds', 'Monitor crash rate daily'] },
        { id: 's3', problemId: 'p3', title: 'UX Redesign Sprint', description: 'Focused sprint to address navigation, loading states and mobile experience', feasibility: 'high', timeframe: '10 days', resources: '2 designers, 2 frontend engineers', owner: 'Lisa Wang', steps: ['Create new navigation prototypes', 'Design loading state library', 'Rebuild mobile layouts', 'User test revised designs', 'Implement approved designs'] },
        { id: 's4', problemId: 'p4', title: 'Safari Compatibility Fix', description: 'Identify and fix all Safari 16 breaking changes with cross-browser testing suite', feasibility: 'high', timeframe: '3 days', resources: '1 engineer, BrowserStack access', owner: 'Marcus Johnson', steps: ['Identify breaking CSS/JS for Safari 16', 'Apply polyfills', 'Test across Safari versions', 'Set up automated cross-browser CI'] }
      ],
      nextSteps: [
        'Daily standups to track API performance improvements',
        'Weekly crash rate monitoring until below 1%',
        'Schedule user testing for UX fixes by Dec 8',
        'Begin senior engineer interviews next week',
        'Q1 2025 planning session to reschedule postponed features'
      ],
      sentiment: 'mixed',
      topics: [
        { name: 'API Performance', duration: 15, percentage: 25, color: '#6366f1' },
        { name: 'Mobile Issues', duration: 18, percentage: 30, color: '#8b5cf6' },
        { name: 'UX/Design', duration: 12, percentage: 20, color: '#a78bfa' },
        { name: 'Hiring', duration: 9, percentage: 15, color: '#c4b5fd' },
        { name: 'Planning', duration: 6, percentage: 10, color: '#ddd6fe' }
      ],
      participants: [
        { name: 'Sarah Chen', speakingTime: 28, contributions: 15, actionItems: 2, sentiment: 'positive', avatar: 'SC', role: 'Product Director' },
        { name: 'Marcus Johnson', speakingTime: 35, contributions: 18, actionItems: 3, sentiment: 'neutral', avatar: 'MJ', role: 'Engineering Lead' },
        { name: 'Elena Rodriguez', speakingTime: 15, contributions: 8, actionItems: 1, sentiment: 'negative', avatar: 'ER', role: 'Enterprise Architect' },
        { name: 'David Park', speakingTime: 12, contributions: 7, actionItems: 2, sentiment: 'positive', avatar: 'DP', role: 'Backend Engineer' },
        { name: 'Lisa Wang', speakingTime: 10, contributions: 6, actionItems: 2, sentiment: 'neutral', avatar: 'LW', role: 'UX Lead' }
      ],
      wordCloud: [
        { text: 'performance', value: 45, color: '#6366f1' },
        { text: 'API', value: 38, color: '#8b5cf6' },
        { text: 'mobile', value: 35, color: '#a78bfa' },
        { text: 'crash', value: 30, color: '#ec4899' },
        { text: 'UX', value: 28, color: '#14b8a6' },
        { text: 'sprint', value: 25, color: '#f59e0b' },
        { text: 'Redis', value: 22, color: '#6366f1' },
        { text: 'launch', value: 20, color: '#3b82f6' },
        { text: 'testing', value: 18, color: '#10b981' },
        { text: 'engineer', value: 15, color: '#8b5cf6' }
      ],
      timeline: [
        { time: '10:00', event: 'Meeting started - Q4 roadmap review', type: 'milestone' },
        { time: '10:05', event: 'Marcus reported 2-week mobile delay', type: 'concern', speaker: 'Marcus Johnson' },
        { time: '10:15', event: 'Redis caching proposed as solution', type: 'decision', speaker: 'David Park' },
        { time: '10:23', event: 'Social sharing postponed to Q1 2025', type: 'decision', speaker: 'Sarah Chen' },
        { time: '10:30', event: 'UX issues from user testing presented', type: 'concern', speaker: 'Lisa Wang' },
        { time: '10:45', event: '2 senior engineers approved for hire', type: 'decision', speaker: 'Sarah Chen' },
        { time: '10:52', event: 'Safari compatibility issue raised', type: 'concern', speaker: 'Elena Rodriguez' },
        { time: '11:00', event: 'Action items finalized and assigned', type: 'action' },
        { time: '11:05', event: 'Meeting concluded', type: 'milestone' }
      ],
      riskAssessment: [
        { id: 'r1', title: 'December Launch Delay Risk', probability: 'high', impact: 'high', mitigation: 'Prioritize P0 items, hire contractors if needed, daily progress reviews', owner: 'Sarah Chen' },
        { id: 'r2', title: 'Enterprise Client Churn', probability: 'medium', impact: 'high', mitigation: 'Proactive communication, offer SLA credits, provide performance timeline', owner: 'Elena Rodriguez' },
        { id: 'r3', title: 'Engineering Team Bandwidth', probability: 'high', impact: 'medium', mitigation: 'Fast-track hiring, redistribute non-critical work to Q1', owner: 'Sarah Chen' }
      ],
      meetingScore: 72
    }
  },
  {
    id: '2',
    title: 'Annual Business Strategy Review 2025',
    date: '2024-12-10',
    duration: '2h 15m',
    participants: ['Jennifer Walsh', 'Robert Kim', 'Amanda Foster', 'Chris Nguyen'],
    fileType: 'application/pdf',
    fileName: 'strategy_review_2025.pdf',
    status: 'completed',
    fileSize: '2.1 MB',
    tags: ['Strategy', 'Business', '2025'],
    transcript: `Strategic review covering market expansion, competitor analysis, and 2025 budget allocation...`,
    summary: {
      overview: "Annual strategy review for 2025 covering European market expansion, competitor positioning, enterprise pricing strategy, and key acquisitions. Team identified significant growth opportunities and approved $2M European expansion budget.",
      keyPoints: [
        "European market represents $12M addressable opportunity",
        "Competitor analysis shows 20% market share gap to close",
        "Enterprise tier pricing revision needed",
        "Partnership with TechCorp approved",
        "AI startup acquisition under consideration for $5M"
      ],
      actionItems: [
        { id: 'a6', task: 'Prepare European expansion go-to-market plan', assignee: 'Amanda Foster', deadline: 'Jan 15, 2025', priority: 'high', status: 'pending', category: 'Strategy' },
        { id: 'a7', task: 'Finalize enterprise pricing model revision', assignee: 'Robert Kim', deadline: 'Jan 10, 2025', priority: 'high', status: 'in-progress', category: 'Revenue' },
        { id: 'a8', task: 'Complete TechCorp partnership due diligence', assignee: 'Jennifer Walsh', deadline: 'Jan 20, 2025', priority: 'medium', status: 'pending', category: 'Partnerships' },
        { id: 'a9', task: 'AI startup acquisition feasibility report', assignee: 'Chris Nguyen', deadline: 'Feb 1, 2025', priority: 'medium', status: 'pending', category: 'M&A' }
      ],
      decisions: [
        { id: 'd4', decision: 'Approve $2M European expansion budget', madeBy: 'Jennifer Walsh', impact: 'high', rationale: 'European market shows 3x ROI potential based on competitive analysis', timestamp: '11:30 AM' },
        { id: 'd5', decision: 'Launch enterprise tier at $999/month', madeBy: 'Robert Kim', impact: 'high', rationale: 'Competitive analysis shows room for premium positioning', timestamp: '12:15 PM' },
        { id: 'd6', decision: 'Approve TechCorp partnership', madeBy: 'Jennifer Walsh', impact: 'medium', rationale: 'Strategic access to 500+ enterprise customers', timestamp: '1:00 PM' }
      ],
      problems: [
        { id: 'p5', title: 'High Customer Churn Rate', description: 'Current churn at 8% vs industry average of 5%', severity: 'high', category: 'Business', identifiedBy: 'Jennifer Walsh', context: 'Churn has been increasing over last 2 quarters', impact: 'Losing $400K ARR quarterly, growth rate declining' },
        { id: 'p6', title: 'Low Brand Awareness in EMEA', description: 'Brand recognition in EMEA region only 12% of target market', severity: 'high', category: 'Marketing', identifiedBy: 'Amanda Foster', context: 'European expansion planned but brand presence nearly zero', impact: 'Expansion ROI at risk without brand investment' },
        { id: 'p7', title: 'Sales Pipeline Conversion Drop', description: 'Conversion rate dropped from 24% to 18% over 6 months', severity: 'medium', category: 'Sales', identifiedBy: 'Robert Kim', context: 'Competitive pressure and longer sales cycles', impact: 'Revenue target miss projected at 15% if trend continues' }
      ],
      solutions: [
        { id: 's5', problemId: 'p5', title: 'Customer Success Program Overhaul', description: 'Redesign customer success journey with proactive health scoring', feasibility: 'high', timeframe: '3 months', resources: 'CS team + CRM upgrade $50K', owner: 'Jennifer Walsh', steps: ['Implement health score model', 'Create playbooks for at-risk accounts', 'Add CSM for enterprise tier', 'Quarterly business reviews', 'NPS improvement program'] },
        { id: 's6', problemId: 'p6', title: 'EMEA Brand Investment Campaign', description: 'Targeted digital and event marketing for European brand building', feasibility: 'medium', timeframe: '6 months', resources: '$500K marketing budget', owner: 'Amanda Foster', steps: ['Hire EMEA marketing manager', 'Sponsor 3 major EU tech conferences', 'Launch localized content strategy', 'Partner with EU analyst firms', 'PR campaign in top EU tech media'] },
        { id: 's7', problemId: 'p7', title: 'Sales Process Optimization', description: 'Revamp sales methodology with better qualification and nurturing', feasibility: 'high', timeframe: '2 months', resources: 'Sales training $30K, sales ops hire', owner: 'Robert Kim', steps: ['Implement MEDDIC sales methodology', 'Create industry-specific use case library', 'Add sales engineer to complex deals', 'Improve demo experience', 'Introduce POC program'] }
      ],
      nextSteps: [
        'Board presentation on European expansion by Dec 20',
        'Enterprise pricing announcement in January newsletter',
        'TechCorp partnership announcement Q1 2025',
        'AI acquisition decision by end of Q1 2025'
      ],
      sentiment: 'positive',
      topics: [
        { name: 'Market Expansion', duration: 35, percentage: 26, color: '#6366f1' },
        { name: 'Pricing Strategy', duration: 25, percentage: 19, color: '#8b5cf6' },
        { name: 'Partnerships', duration: 20, percentage: 15, color: '#a78bfa' },
        { name: 'Competitor Analysis', duration: 30, percentage: 22, color: '#3b82f6' },
        { name: 'Financial Planning', duration: 25, percentage: 18, color: '#10b981' }
      ],
      participants: [
        { name: 'Jennifer Walsh', speakingTime: 40, contributions: 20, actionItems: 2, sentiment: 'positive', avatar: 'JW', role: 'CEO' },
        { name: 'Robert Kim', speakingTime: 30, contributions: 15, actionItems: 2, sentiment: 'positive', avatar: 'RK', role: 'CFO' },
        { name: 'Amanda Foster', speakingTime: 25, contributions: 12, actionItems: 2, sentiment: 'positive', avatar: 'AF', role: 'CMO' },
        { name: 'Chris Nguyen', speakingTime: 20, contributions: 10, actionItems: 1, sentiment: 'neutral', avatar: 'CN', role: 'CTO' }
      ],
      wordCloud: [
        { text: 'European', value: 50, color: '#6366f1' },
        { text: 'expansion', value: 45, color: '#8b5cf6' },
        { text: 'enterprise', value: 40, color: '#3b82f6' },
        { text: 'revenue', value: 35, color: '#10b981' },
        { text: 'market', value: 32, color: '#f59e0b' },
        { text: 'partnership', value: 28, color: '#ec4899' },
        { text: 'acquisition', value: 25, color: '#6366f1' },
        { text: 'churn', value: 22, color: '#ef4444' },
        { text: 'pricing', value: 20, color: '#a78bfa' },
        { text: 'brand', value: 18, color: '#14b8a6' }
      ],
      timeline: [
        { time: '10:00', event: 'Strategy review opened', type: 'milestone' },
        { time: '10:30', event: 'European expansion proposal presented', type: 'discussion', speaker: 'Amanda Foster' },
        { time: '11:00', event: '$2M expansion budget approved', type: 'decision', speaker: 'Jennifer Walsh' },
        { time: '11:30', event: 'Enterprise pricing discussion', type: 'discussion', speaker: 'Robert Kim' },
        { time: '12:00', event: '$999/month enterprise tier agreed', type: 'decision', speaker: 'Robert Kim' },
        { time: '12:30', event: 'TechCorp partnership discussion', type: 'discussion' },
        { time: '13:00', event: 'Partnership approved, due diligence assigned', type: 'action', speaker: 'Jennifer Walsh' },
        { time: '13:30', event: 'AI acquisition feasibility discussion', type: 'discussion', speaker: 'Chris Nguyen' },
        { time: '14:00', event: 'Action items reviewed and confirmed', type: 'action' },
        { time: '14:15', event: 'Meeting concluded', type: 'milestone' }
      ],
      riskAssessment: [
        { id: 'r4', title: 'European Regulatory Compliance', probability: 'high', impact: 'high', mitigation: 'Engage EU legal counsel, GDPR compliance audit, local data residency', owner: 'Jennifer Walsh' },
        { id: 'r5', title: 'Competitor Response to Enterprise Pricing', probability: 'medium', impact: 'medium', mitigation: 'Rapid differentiation, value-added services, loyalty program', owner: 'Robert Kim' }
      ],
      meetingScore: 88
    }
  }
];

export const AI_KNOWLEDGE_BASE: Record<string, string[]> = {
  "api performance": [
    "In the Q4 Product Roadmap Planning meeting (Dec 15), API response times were identified as averaging 2.3 seconds, 40% above the 1.4 second benchmark.",
    "David Park proposed Redis caching as the solution, expected to fix 60-70% of the performance issue.",
    "This was classified as a P0 (critical) priority item requiring immediate action."
  ],
  "mobile": [
    "The mobile app crash rate was identified at 2.3%, far exceeding the 0.5% target.",
    "Mobile features are 2 weeks behind schedule due to complex API integration.",
    "3 critical UX issues were found in mobile testing: confusing navigation, unclear loading states, and poor mobile experience."
  ],
  "hiring": [
    "In the Q4 roadmap meeting, 2 senior engineer positions were approved due to team bandwidth constraints.",
    "The annual strategy review (Dec 10) also noted engineering scaling as a priority for 2025.",
    "HR was tasked with posting openings by December 2, 2024."
  ],
  "european expansion": [
    "The 2025 Strategy Review approved a $2M European expansion budget.",
    "European market represents a $12M total addressable opportunity.",
    "Brand awareness in EMEA is currently only 12% of the target market.",
    "Go-to-market plan is due January 15, 2025, owned by Amanda Foster."
  ],
  "churn": [
    "Customer churn rate is at 8%, vs the industry average of 5%.",
    "Churn has been increasing over the last 2 quarters, causing $400K ARR quarterly loss.",
    "The solution proposed is a Customer Success Program overhaul with health scoring and proactive interventions."
  ],
  "action items": [
    "Q4 Roadmap: Redis caching (David Park, Dec 8), UX fixes (Lisa Wang, Dec 10), crash rate fix (Marcus Johnson, Dec 15)",
    "Strategy: European GTM plan (Amanda Foster, Jan 15), Enterprise pricing (Robert Kim, Jan 10), TechCorp due diligence (Jennifer Walsh, Jan 20)"
  ],
  "problems": [
    "Critical: API performance (2.3s vs 1.4s benchmark), Mobile crash rate (2.3% vs 0.5% target)",
    "High: UX issues in testing, Safari 16 compatibility, Customer churn (8% vs 5%), Low EMEA brand awareness",
    "Medium: Sales conversion drop (24% to 18%), Forecast accuracy (72% vs 90% target)"
  ],
  "solutions": [
    "API: Redis caching implementation (David Park, 5 days)",
    "Mobile crashes: Dedicated crash fix sprint using Crashlytics (Marcus Johnson, 2 weeks)",
    "Churn: Customer Success Program overhaul with health scoring (Jennifer Walsh, 3 months)",
    "EMEA Brand: $500K marketing campaign, EU conferences, localized content (Amanda Foster, 6 months)"
  ],
  "decisions": [
    "Postpone social sharing to Q1 2025 (focus on core quality)",
    "Hire 2 senior engineers immediately",
    "Redis caching as P0 priority",
    "Approve $2M European expansion budget",
    "Enterprise tier at $999/month",
    "TechCorp partnership approved"
  ],
  "enterprise": [
    "Enterprise tier pricing set at $999/month in the 2025 Strategy Review.",
    "Enterprise clients are experiencing API performance issues (2.3s response time).",
    "Enterprise clients need custom SLA agreements - identified as a gap.",
    "TechCorp partnership provides access to 500+ enterprise customers."
  ],
  "revenue": [
    "Q3 2024 revenue was $4.2M, 10% above target.",
    "Gross margin improved to 68%.",
    "European market represents $12M TAM opportunity.",
    "Churn is costing $400K ARR quarterly.",
    "Sales conversion drop could cause 15% revenue target miss."
  ]
};

export const generateAnalysis = (fileName: string, fileType: string): Meeting => {
  const analysisTemplates = [
    {
      title: `Analysis: ${fileName}`,
      topics: ['Requirements', 'Timeline', 'Budget', 'Resources', 'Risks'],
      participants: ['Meeting Host', 'Stakeholder A', 'Stakeholder B', 'Subject Expert'],
      problems: [
        { title: 'Resource Constraint', description: 'Insufficient team capacity for parallel work streams', severity: 'high' as const, category: 'Resource Management' },
        { title: 'Timeline Pressure', description: 'Aggressive deadline with insufficient buffer for contingencies', severity: 'medium' as const, category: 'Project Management' },
        { title: 'Unclear Requirements', description: 'Some acceptance criteria are ambiguous and need stakeholder sign-off', severity: 'high' as const, category: 'Requirements' }
      ],
      solutions: [
        { title: 'Resource Augmentation', description: 'Bring in 2 contractors to supplement core team', timeframe: '2 weeks', feasibility: 'high' as const },
        { title: 'Phased Delivery', description: 'Break deliverable into 3 phases with clear milestones', timeframe: '1 week to plan', feasibility: 'high' as const },
        { title: 'Requirements Workshop', description: 'Schedule 2-hour requirements refinement session with all stakeholders', timeframe: '3 days', feasibility: 'high' as const }
      ]
    }
  ];

  const template = analysisTemplates[0];
  const now = new Date();

  return {
    id: Math.random().toString(36).substr(2, 9),
    title: `Analysis: ${fileName}`,
    date: now.toISOString().split('T')[0],
    duration: `${Math.floor(Math.random() * 90 + 30)}m`,
    participants: template.participants,
    fileType,
    fileName,
    status: 'completed',
    fileSize: `${(Math.random() * 50 + 1).toFixed(1)} MB`,
    tags: ['Uploaded', 'Analyzed'],
    summary: {
      overview: `AI analysis of "${fileName}" completed successfully. The document/audio contains meeting content covering multiple key business topics including planning, resource allocation, and strategic decisions. ${template.problems.length} problems were identified with corresponding solutions.`,
      keyPoints: [
        'Document successfully parsed and analyzed by AI',
        'Multiple stakeholder perspectives identified and mapped',
        'Critical path items extracted and prioritized',
        'Risk factors assessed with mitigation strategies provided',
        'Action items extracted and assigned to responsible parties',
        'Knowledge base updated with insights from this document'
      ],
      actionItems: [
        { id: Math.random().toString(36), task: 'Review and approve identified requirements', assignee: 'Meeting Host', deadline: 'Next week', priority: 'high', status: 'pending', category: 'Governance' },
        { id: Math.random().toString(36), task: 'Allocate resources for Phase 1 delivery', assignee: 'Stakeholder A', deadline: 'End of month', priority: 'high', status: 'pending', category: 'Resource' },
        { id: Math.random().toString(36), task: 'Schedule requirements validation workshop', assignee: 'Subject Expert', deadline: 'This week', priority: 'medium', status: 'pending', category: 'Planning' }
      ],
      decisions: [
        { id: Math.random().toString(36), decision: 'Proceed with phased delivery approach', madeBy: 'Meeting Host', impact: 'high', rationale: 'Reduces risk and allows early feedback', timestamp: '10:30 AM' },
        { id: Math.random().toString(36), decision: 'Engage external contractors for resource gap', madeBy: 'Stakeholder A', impact: 'medium', rationale: 'Critical path requires additional capacity', timestamp: '11:00 AM' }
      ],
      problems: template.problems.map((p, i) => ({
        id: `p${i + 10}`,
        title: p.title,
        description: p.description,
        severity: p.severity,
        category: p.category,
        identifiedBy: template.participants[i % template.participants.length],
        context: 'Identified during document analysis',
        impact: 'Impacts project delivery and stakeholder satisfaction'
      })),
      solutions: template.solutions.map((s, i) => ({
        id: `s${i + 10}`,
        problemId: `p${i + 10}`,
        title: s.title,
        description: s.description,
        feasibility: s.feasibility,
        timeframe: s.timeframe,
        resources: 'To be determined based on availability',
        owner: template.participants[i % template.participants.length],
        steps: ['Initiate planning', 'Gather requirements', 'Execute solution', 'Validate results', 'Document outcomes']
      })),
      nextSteps: [
        'Share analysis report with all stakeholders',
        'Schedule follow-up meeting to review findings',
        'Begin implementation of approved solutions',
        'Set up monitoring for identified risks'
      ],
      sentiment: 'neutral',
      topics: template.topics.map((t, i) => ({
        name: t,
        duration: Math.floor(Math.random() * 20 + 10),
        percentage: Math.floor(100 / template.topics.length),
        color: ['#6366f1', '#8b5cf6', '#a78bfa', '#3b82f6', '#10b981'][i % 5]
      })),
      participants: template.participants.map((p, i) => ({
        name: p,
        speakingTime: Math.floor(Math.random() * 30 + 10),
        contributions: Math.floor(Math.random() * 15 + 5),
        actionItems: Math.floor(Math.random() * 3 + 1),
        sentiment: ['positive', 'neutral', 'negative'][i % 3] as 'positive' | 'neutral' | 'negative',
        avatar: p.split(' ').map(n => n[0]).join('').substring(0, 2),
        role: ['Host', 'Stakeholder', 'Expert', 'Observer'][i % 4]
      })),
      wordCloud: [
        { text: 'requirements', value: 45, color: '#6366f1' },
        { text: 'delivery', value: 38, color: '#8b5cf6' },
        { text: 'timeline', value: 32, color: '#3b82f6' },
        { text: 'resources', value: 28, color: '#10b981' },
        { text: 'risk', value: 25, color: '#ef4444' },
        { text: 'stakeholder', value: 22, color: '#f59e0b' },
        { text: 'phase', value: 20, color: '#a78bfa' },
        { text: 'review', value: 18, color: '#14b8a6' }
      ],
      timeline: [
        { time: 'Start', event: 'Document/Meeting begins', type: 'milestone' as const },
        { time: '+15m', event: 'Key issues identified', type: 'concern' as const },
        { time: '+30m', event: 'Solutions proposed', type: 'discussion' as const },
        { time: '+45m', event: 'Decisions made', type: 'decision' as const },
        { time: '+60m', event: 'Action items assigned', type: 'action' as const },
        { time: 'End', event: 'Document/Meeting concludes', type: 'milestone' as const }
      ],
      riskAssessment: [
        { id: 'r10', title: 'Delivery Timeline Risk', probability: 'high', impact: 'high', mitigation: 'Implement phased delivery, weekly progress reviews, buffer time added', owner: template.participants[0] }
      ],
      meetingScore: Math.floor(Math.random() * 30 + 60)
    }
  };
};
