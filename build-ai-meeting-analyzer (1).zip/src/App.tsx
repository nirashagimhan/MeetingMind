import React, { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import Navbar from './components/Navbar';
import HomePage from './components/HomePage';
import UploadPage from './components/UploadPage';
import DashboardPage from './components/DashboardPage';
import ChatPage from './components/ChatPage';
import AnalysisPage from './components/AnalysisPage';
import InsightsPage from './components/InsightsPage';
import { Meeting } from './types';
import { SAMPLE_MEETINGS } from './data/mockDatabase';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState('home');
  const [meetings, setMeetings] = useState<Meeting[]>(SAMPLE_MEETINGS);
  const [selectedMeeting, setSelectedMeeting] = useState<Meeting | null>(SAMPLE_MEETINGS[0]);

  const handleMeetingAnalyzed = (meeting: Meeting) => {
    setMeetings(prev => [meeting, ...prev]);
    setSelectedMeeting(meeting);
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage setCurrentPage={setCurrentPage} />;
      case 'upload':
        return (
          <UploadPage
            onMeetingAnalyzed={handleMeetingAnalyzed}
            setCurrentPage={setCurrentPage}
            setSelectedMeeting={setSelectedMeeting}
          />
        );
      case 'dashboard':
        return (
          <DashboardPage
            meetings={meetings}
            setCurrentPage={setCurrentPage}
            setSelectedMeeting={setSelectedMeeting}
          />
        );
      case 'chat':
        return <ChatPage meetings={meetings} />;
      case 'analysis':
        return selectedMeeting ? (
          <AnalysisPage meeting={selectedMeeting} setCurrentPage={setCurrentPage} />
        ) : (
          <DashboardPage meetings={meetings} setCurrentPage={setCurrentPage} setSelectedMeeting={setSelectedMeeting} />
        );
      case 'insights':
        return (
          <InsightsPage
            meetings={meetings}
            setCurrentPage={setCurrentPage}
            setSelectedMeeting={setSelectedMeeting}
          />
        );
      default:
        return <HomePage setCurrentPage={setCurrentPage} />;
    }
  };

  return (
    <div className="font-['Inter',sans-serif] bg-[#050510] min-h-screen">
      <Navbar currentPage={currentPage} setCurrentPage={setCurrentPage} />
      <AnimatePresence mode="wait">
        <motion.div
          key={currentPage}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
        >
          {renderPage()}
        </motion.div>
      </AnimatePresence>
    </div>
  );
};

export default App;
